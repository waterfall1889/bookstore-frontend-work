import React from 'react';
import ManagerLayout from "../../components/manager_layout";

export default function ManagerHomePage() {
    return (
        <ManagerLayout>
        </ManagerLayout>
    );
}