import React from 'react';
import BasicLayout from '../components/layout';

export default function HomePage() {
    return (
        <BasicLayout>
        </BasicLayout>
    );
}
