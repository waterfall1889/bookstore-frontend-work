package org.controllers;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    // 配置全局 CORS 策略
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        // 允许来自 localhost:3000 的请求
        registry.addMapping("/**")
                .allowedOriginPatterns("*") // 开发测试用
                .allowedMethods("*")
                .allowedHeaders("*")
                .allowCredentials(false)  // 是否允许发送 Cookie
                .maxAge(3600);  // 预检请求的最大缓存时间，单位秒
    }
}

