package org.controllers.demo.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {
    // 不再需要密码加密配置
} 