package org.controllers.demo.config;

import org.controllers.demo.service.BookTagService;
import org.controllers.demo.service.Neo4jTagService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.EventListener;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 标签系统初始化器
 * 在应用完全启动后自动初始化Neo4J标签关系图
 */
@Component
public class TagInitializer implements ApplicationListener<ApplicationReadyEvent> {
    private static final Logger logger = LoggerFactory.getLogger(TagInitializer.class);

    @Autowired(required = false)
    private Neo4jTagService neo4jTagService;

    @Autowired(required = false)
    private BookTagService bookTagService;

    @Override
    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationEvent(ApplicationReadyEvent event) {
        // 延迟初始化，确保Neo4J完全配置好
        new Thread(() -> {
            try {
                // 等待一下，确保所有Bean都完全初始化
                Thread.sleep(2000);
                
                if (neo4jTagService != null) {
                    logger.info("开始初始化标签关系图...");
                    neo4jTagService.initializeTagGraph();
                    logger.info("标签关系图初始化完成");
                } else {
                    logger.warn("Neo4jTagService未注入，跳过标签关系图初始化");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.error("初始化线程被中断", e);
            } catch (Exception e) {
                logger.error("初始化标签关系图失败，但应用继续运行。可以通过API手动初始化: POST /api/tags/init-graph", e);
                // 不抛出异常，允许应用继续运行
            }
        }).start();
    }
}

