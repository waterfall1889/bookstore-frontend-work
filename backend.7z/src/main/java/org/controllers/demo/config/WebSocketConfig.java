package org.controllers.demo.config;

import org.controllers.demo.websocket.OrderWebSocketHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.*;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

/**
 * WebSocket 配置类
 * 配置WebSocket端点和处理器
 */
@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Bean
    public OrderWebSocketHandler orderWebSocketHandler() {
        return new OrderWebSocketHandler();
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // 注册WebSocket处理器
        // 路径: /ws/order
        // 允许跨域: setAllowedOrigins("*")
        registry.addHandler(orderWebSocketHandler(), "/ws/order")
                .setAllowedOrigins("*");
    }
}

