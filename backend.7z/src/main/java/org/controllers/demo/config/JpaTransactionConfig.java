package org.controllers.demo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import jakarta.persistence.EntityManagerFactory;

/**
 * JPA事务管理器配置
 * 确保JPA使用默认的transactionManager，不影响Neo4j的事务管理器
 */
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
    basePackages = "org.controllers.demo.repository",
    transactionManagerRef = "transactionManager"
)
public class JpaTransactionConfig {
    private static final Logger logger = LoggerFactory.getLogger(JpaTransactionConfig.class);

    /**
     * 配置JPA事务管理器为默认（Primary）
     * 这样所有使用@Transactional的服务都会使用这个事务管理器
     */
    @Bean(name = "transactionManager")
    @Primary
    public PlatformTransactionManager transactionManager(@Autowired EntityManagerFactory entityManagerFactory) {
        logger.info("========== JPA事务管理器配置 ==========");
        logger.info("配置JPA默认事务管理器（transactionManager）");
        logger.info("=====================================");
        return new JpaTransactionManager(entityManagerFactory);
    }
}

