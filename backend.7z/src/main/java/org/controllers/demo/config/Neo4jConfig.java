package org.controllers.demo.config;

import org.neo4j.driver.Driver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.core.DatabaseSelectionProvider;
import org.springframework.data.neo4j.core.transaction.Neo4jTransactionManager;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * Neo4j配置类
 * 配置连接到指定的数据库实例 booktag
 * 注意：此配置不会影响JPA的默认事务管理器（transactionManager）
 */
@Configuration
@EnableNeo4jRepositories(
    basePackages = "org.controllers.demo.repository.neo4j",
    transactionManagerRef = "neo4jTransactionManager"
)
public class Neo4jConfig {
    private static final Logger logger = LoggerFactory.getLogger(Neo4jConfig.class);

    @Value("${spring.neo4j.database:booktag}")
    private String databaseName;

    /**
     * 配置数据库选择提供者，指定使用booktag数据库
     */
    @Bean
    public DatabaseSelectionProvider databaseSelectionProvider() {
        logger.info("========== Neo4j数据库配置 ==========");
        logger.info("配置Neo4j数据库选择提供者，使用数据库: {}", databaseName);
        logger.info("=====================================");
        return () -> org.springframework.data.neo4j.core.DatabaseSelection.byName(databaseName);
    }

    /**
     * 配置Neo4j事务管理器，使用指定的数据库
     * 注意：
     * 1. 这个bean有明确的名称"neo4jTransactionManager"，不会覆盖JPA的默认"transactionManager"
     * 2. Spring Boot会自动为JPA创建名为"transactionManager"的事务管理器
     * 3. Neo4j Repository使用neo4jTransactionManager，JPA Repository使用默认的transactionManager
     */
    @Bean(name = "neo4jTransactionManager")
    public PlatformTransactionManager neo4jTransactionManager(Driver driver, DatabaseSelectionProvider databaseSelectionProvider) {
        logger.info("配置Neo4j事务管理器（neo4jTransactionManager），使用数据库: {}", databaseName);
        logger.info("注意：JPA的默认事务管理器（transactionManager）不受影响");
        return new Neo4jTransactionManager(driver, databaseSelectionProvider);
    }
}

