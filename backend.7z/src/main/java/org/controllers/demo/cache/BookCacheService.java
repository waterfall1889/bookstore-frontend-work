package org.controllers.demo.cache;

import org.controllers.demo.entity.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 图书缓存服务
 * 将图书基础信息和库存信息分离缓存：
 * - 基础信息（itemName, author, price, coverUrl, isbn, publish, validness）使用Hash结构，TTL较长
 * - 库存信息（remainNumber）单独存储，便于快速更新
 */
@Service
public class BookCacheService {
    private static final Logger logger = LoggerFactory.getLogger(BookCacheService.class);
    
    // 缓存key前缀
    private static final String BOOK_INFO_PREFIX = "book:info:";  // 图书基础信息
    private static final String BOOK_STOCK_PREFIX = "book:stock:"; // 图书库存
    private static final String BOOK_LIST_KEY = "book:list:all";  // 所有图书列表
    
    // 缓存过期时间（秒）
    private static final long BOOK_INFO_TTL = 3600;  // 基础信息缓存1小时
    private static final long BOOK_STOCK_TTL = 1800; // 库存信息缓存30分钟
    private static final long BOOK_LIST_TTL = 1800;  // 图书列表缓存30分钟
    
    @Autowired(required = false)
    private RedisTemplate<String, Object> redisTemplate;
    
    /**
     * 初始化时检查Redis连接状态
     */
    @jakarta.annotation.PostConstruct
    public void init() {
        if (redisTemplate != null) {
            try {
                redisTemplate.hasKey("health_check");
                logger.info("========== Redis缓存服务初始化成功 ==========");
                logger.info("✅ Redis连接正常，缓存功能已启用");
                logger.info("缓存配置: 基础信息TTL={}秒, 库存信息TTL={}秒", BOOK_INFO_TTL, BOOK_STOCK_TTL);
            } catch (Exception e) {
                logger.warn("========== Redis缓存服务初始化警告 ==========");
                logger.warn("⚠️ Redis连接失败: {}", e.getMessage());
                logger.warn("系统将降级到数据库模式，所有操作将直接访问数据库");
                logger.warn("==========================================");
            }
        } else {
            logger.warn("========== Redis缓存服务未初始化 ==========");
            logger.warn("⚠️ RedisTemplate为null，Redis缓存功能不可用");
            logger.warn("系统将降级到数据库模式，所有操作将直接访问数据库");
            logger.warn("==========================================");
        }
    }
    
    private boolean isRedisAvailable() {
        if (redisTemplate == null) {
            logger.debug("[Redis] RedisTemplate未初始化，Redis不可用");
            return false;
        }
        try {
            // 简单的连接测试
            redisTemplate.hasKey("test");
            logger.debug("[Redis] 连接测试成功");
            return true;
        } catch (Exception e) {
            logger.warn("[Redis] ⚠️ Redis连接不可用: {}", e.getMessage());
            logger.debug("[Redis] 异常详情: ", e);
            return false;
        }
    }

    /**
     * 从缓存获取图书基础信息（不包含库存）
     */
    public Map<String, Object> getBookInfo(String itemId) {
        String key = BOOK_INFO_PREFIX + itemId;
        logger.debug("[Redis读取] 尝试读取图书基础信息 - key: {}, itemId: {}", key, itemId);
        
        if (!isRedisAvailable()) {
            logger.warn("[Redis读取] ❌ Redis不可用，跳过缓存读取 - itemId: {}", itemId);
            return null;
        }
        
        try {
            Map<Object, Object> hash = redisTemplate.opsForHash().entries(key);
            if (hash == null || hash.isEmpty()) {
                logger.info("[Redis读取] ⚠️ 缓存未命中（基础信息） - key: {}, itemId: {}", key, itemId);
                return null;
            }
            
            Map<String, Object> result = new HashMap<>();
            for (Map.Entry<Object, Object> entry : hash.entrySet()) {
                result.put(entry.getKey().toString(), entry.getValue());
            }
            
            logger.info("[Redis读取] ✅ 缓存命中（基础信息） - key: {}, itemId: {}, 字段数: {}", 
                key, itemId, result.size());
            logger.debug("[Redis读取] 缓存内容: {}", result);
            return result;
        } catch (Exception e) {
            logger.error("[Redis读取] ❌ 读取图书基础信息失败 - key: {}, itemId: {}", key, itemId, e);
            return null;
        }
    }

    /**
     * 从缓存获取图书库存
     */
    public Integer getBookStock(String itemId) {
        String key = BOOK_STOCK_PREFIX + itemId;
        logger.debug("[Redis读取] 尝试读取图书库存 - key: {}, itemId: {}", key, itemId);
        
        if (!isRedisAvailable()) {
            logger.warn("[Redis读取] ❌ Redis不可用，跳过库存缓存读取 - itemId: {}", itemId);
            return null;
        }
        
        try {
            Object stock = redisTemplate.opsForValue().get(key);
            if (stock == null) {
                logger.info("[Redis读取] ⚠️ 缓存未命中（库存） - key: {}, itemId: {}", key, itemId);
                return null;
            }
            
            Integer stockValue = stock instanceof Integer ? (Integer) stock : Integer.parseInt(stock.toString());
            logger.info("[Redis读取] ✅ 缓存命中（库存） - key: {}, itemId: {}, stock: {}", 
                key, itemId, stockValue);
            return stockValue;
        } catch (Exception e) {
            logger.error("[Redis读取] ❌ 读取图书库存失败 - key: {}, itemId: {}", key, itemId, e);
            return null;
        }
    }

    /**
     * 从缓存获取完整图书信息（基础信息+库存）
     */
    public Item getBook(String itemId) {
        logger.debug("[Redis读取] 尝试从缓存获取完整图书信息 - itemId: {}", itemId);
        
        Map<String, Object> info = getBookInfo(itemId);
        Integer stock = getBookStock(itemId);
        
        if (info == null || stock == null) {
            logger.info("[Redis读取] ⚠️ 缓存不完整，无法构建完整图书信息 - itemId: {} (info: {}, stock: {})", 
                itemId, info != null, stock != null);
            return null;
        }
        
        try {
            Item item = new Item();
            item.setItemId(itemId);
            if (info.get("itemName") != null) item.setItemName(info.get("itemName").toString());
            if (info.get("author") != null) item.setAuthor(info.get("author").toString());
            if (info.get("price") != null) {
                item.setPrice(new java.math.BigDecimal(info.get("price").toString()));
            }
            if (info.get("coverUrl") != null) item.setCoverUrl(info.get("coverUrl").toString());
            if (info.get("isbn") != null) item.setIsbn(info.get("isbn").toString());
            if (info.get("publish") != null) item.setPublish(info.get("publish").toString());
            if (info.get("validness") != null) {
                item.setValidness(Integer.parseInt(info.get("validness").toString()));
            }
            item.setRemainNumber(stock);
            
            logger.info("[Redis读取] ✅ 从缓存构建完整图书信息成功 - itemId: {}, 书名: {}, 库存: {}", 
                itemId, item.getItemName(), stock);
            return item;
        } catch (Exception e) {
            logger.error("[Redis读取] ❌ 从缓存构建图书信息失败 - itemId: {}", itemId, e);
            return null;
        }
    }

    /**
     * 缓存图书基础信息
     */
    public void setBookInfo(Item item) {
        String key = BOOK_INFO_PREFIX + item.getItemId();
        logger.debug("[Redis写入] 尝试写入图书基础信息 - key: {}, itemId: {}", key, item.getItemId());
        
        if (!isRedisAvailable()) {
            logger.warn("[Redis写入] ❌ Redis不可用，跳过基础信息缓存写入 - itemId: {}", item.getItemId());
            return;
        }
        
        try {
            Map<String, Object> hash = new HashMap<>();
            hash.put("itemId", item.getItemId());
            hash.put("itemName", item.getItemName());
            hash.put("author", item.getAuthor());
            hash.put("price", item.getPrice() != null ? item.getPrice().toString() : null);
            hash.put("coverUrl", item.getCoverUrl());
            hash.put("isbn", item.getIsbn());
            hash.put("publish", item.getPublish());
            hash.put("validness", item.getValidness());
            
            redisTemplate.opsForHash().putAll(key, hash);
            redisTemplate.expire(key, BOOK_INFO_TTL, TimeUnit.SECONDS);
            
            logger.info("[Redis写入] ✅ 写入图书基础信息到缓存成功 - key: {}, itemId: {}, TTL: {}秒, 字段数: {}", 
                key, item.getItemId(), BOOK_INFO_TTL, hash.size());
            logger.debug("[Redis写入] 写入内容: {}", hash);
        } catch (Exception e) {
            logger.error("[Redis写入] ❌ 写入图书基础信息到缓存失败 - key: {}, itemId: {}", 
                key, item.getItemId(), e);
        }
    }

    /**
     * 缓存图书库存
     */
    public void setBookStock(String itemId, Integer stock) {
        String key = BOOK_STOCK_PREFIX + itemId;
        logger.debug("[Redis写入] 尝试写入图书库存 - key: {}, itemId: {}, stock: {}", key, itemId, stock);
        
        if (!isRedisAvailable()) {
            logger.warn("[Redis写入] ❌ Redis不可用，跳过库存缓存写入 - itemId: {}", itemId);
            return;
        }
        
        try {
            redisTemplate.opsForValue().set(key, stock, BOOK_STOCK_TTL, TimeUnit.SECONDS);
            logger.info("[Redis写入] ✅ 写入图书库存到缓存成功 - key: {}, itemId: {}, stock: {}, TTL: {}秒", 
                key, itemId, stock, BOOK_STOCK_TTL);
        } catch (Exception e) {
            logger.error("[Redis写入] ❌ 写入图书库存到缓存失败 - key: {}, itemId: {}, stock: {}", 
                key, itemId, stock, e);
        }
    }

    /**
     * 缓存完整图书信息（基础信息+库存）
     */
    public void setBook(Item item) {
        if (item == null || item.getItemId() == null) {
            return;
        }
        
        // 缓存基础信息（排除库存）
        Item infoOnly = new Item();
        infoOnly.setItemId(item.getItemId());
        infoOnly.setItemName(item.getItemName());
        infoOnly.setAuthor(item.getAuthor());
        infoOnly.setPrice(item.getPrice());
        infoOnly.setCoverUrl(item.getCoverUrl());
        infoOnly.setIsbn(item.getIsbn());
        infoOnly.setPublish(item.getPublish());
        infoOnly.setValidness(item.getValidness());
        
        logger.debug("[Redis写入] 开始写入完整图书信息 - itemId: {}", item.getItemId());
        setBookInfo(infoOnly);
        
        // 单独缓存库存
        if (item.getRemainNumber() != null) {
            setBookStock(item.getItemId(), item.getRemainNumber());
        }
        
        logger.info("[Redis写入] ✅ 写入完整图书信息到缓存成功 - itemId: {}, 书名: {}, 库存: {}", 
            item.getItemId(), item.getItemName(), item.getRemainNumber());
    }

    /**
     * 更新图书库存（原子操作）
     */
    public boolean updateBookStock(String itemId, Integer delta) {
        String key = BOOK_STOCK_PREFIX + itemId;
        logger.debug("[Redis更新] 尝试更新图书库存（原子操作） - key: {}, itemId: {}, delta: {}", 
            key, itemId, delta);
        
        if (!isRedisAvailable()) {
            logger.warn("[Redis更新] ❌ Redis不可用，跳过库存更新 - itemId: {}, delta: {}", itemId, delta);
            return false;
        }
        
        try {
            Long newStock = redisTemplate.opsForValue().increment(key, delta);
            if (newStock != null) {
                redisTemplate.expire(key, BOOK_STOCK_TTL, TimeUnit.SECONDS);
                logger.info("[Redis更新] ✅ 更新图书库存成功（原子操作） - key: {}, itemId: {}, delta: {}, newStock: {}", 
                    key, itemId, delta, newStock);
                return true;
            }
            logger.warn("[Redis更新] ⚠️ 库存更新返回null - key: {}, itemId: {}, delta: {}", key, itemId, delta);
            return false;
        } catch (Exception e) {
            logger.error("[Redis更新] ❌ 更新图书库存失败 - key: {}, itemId: {}, delta: {}", 
                key, itemId, delta, e);
            return false;
        }
    }

    /**
     * 删除图书缓存
     */
    public void deleteBook(String itemId) {
        String infoKey = BOOK_INFO_PREFIX + itemId;
        String stockKey = BOOK_STOCK_PREFIX + itemId;
        logger.debug("[Redis删除] 尝试删除图书缓存 - infoKey: {}, stockKey: {}, itemId: {}", 
            infoKey, stockKey, itemId);
        
        if (!isRedisAvailable()) {
            logger.warn("[Redis删除] ❌ Redis不可用，跳过缓存删除 - itemId: {}", itemId);
            return;
        }
        
        try {
            Boolean infoDeleted = redisTemplate.delete(infoKey);
            Boolean stockDeleted = redisTemplate.delete(stockKey);
            
            // 删除列表缓存
            deleteBookList();
            
            logger.info("[Redis删除] ✅ 删除图书缓存成功 - itemId: {}, infoKey删除: {}, stockKey删除: {}", 
                itemId, infoDeleted, stockDeleted);
        } catch (Exception e) {
            logger.error("[Redis删除] ❌ 删除图书缓存失败 - itemId: {}, infoKey: {}, stockKey: {}", 
                itemId, infoKey, stockKey, e);
        }
    }

    /**
     * 删除图书列表缓存
     */
    public void deleteBookList() {
        logger.debug("[Redis删除] 尝试删除图书列表缓存 - key: {}", BOOK_LIST_KEY);
        
        if (!isRedisAvailable()) {
            return;
        }
        
        try {
            Boolean deleted = redisTemplate.delete(BOOK_LIST_KEY);
            logger.info("[Redis删除] ✅ 删除图书列表缓存成功 - key: {}, 删除结果: {}", BOOK_LIST_KEY, deleted);
        } catch (Exception e) {
            logger.error("[Redis删除] ❌ 删除图书列表缓存失败 - key: {}", BOOK_LIST_KEY, e);
        }
    }

    /**
     * 检查缓存是否存在
     */
    public boolean exists(String itemId) {
        if (!isRedisAvailable()) {
            return false;
        }
        
        try {
            String infoKey = BOOK_INFO_PREFIX + itemId;
            String stockKey = BOOK_STOCK_PREFIX + itemId;
            return redisTemplate.hasKey(infoKey) && redisTemplate.hasKey(stockKey);
        } catch (Exception e) {
            logger.error("检查缓存存在性失败 - itemId: {}", itemId, e);
            return false;
        }
    }
}

