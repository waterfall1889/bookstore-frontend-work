package org.controllers.demo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "order_items")
@IdClass(OrderItemId.class)
public class OrderItem {
    @Id
    @Column(name = "order_id", length = 10)
    private String orderId;

    @Id
    @Column(name = "item_id", length = 9)
    private String itemId;

    @Column(name = "counts")
    private Integer counts;

    @ManyToOne
    @JoinColumn(name = "order_id", insertable = false, updatable = false)
    @JsonBackReference
    private OrderMeta orderMeta;

    @ManyToOne
    @JoinColumn(name = "item_id", insertable = false, updatable = false)
    private Item item;

    @Transient
    public String getUserId() {
        return (this.orderMeta != null) ? this.orderMeta.getUserId() : null;
    }
} 