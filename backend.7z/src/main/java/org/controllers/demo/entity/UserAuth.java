package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "users_auth")
public class UserAuth {
    @Id
    @Column(name = "id", length = 8)
    private String id;

    @Column(name = "validness")
    private Boolean validness = true;

    @Column(name = "salt", length = 16)
    private String salt;

    @Column(name = "hashvalue", length = 64, columnDefinition = "varchar(64)")
    private String hashValue;
} 