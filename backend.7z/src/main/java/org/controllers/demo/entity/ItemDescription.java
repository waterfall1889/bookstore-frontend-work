package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "item_description")
public class ItemDescription {
    @Id
    @Column(name = "item_id", length = 9)
    private String itemId;

    @Column(name = "description", length = 300)
    private String description;
} 