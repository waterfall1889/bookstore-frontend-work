package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.controllers.demo.entity.Item;

@Data
@Entity
@Table(name = "cart_items")
@IdClass(CartItemId.class)
public class CartItem {
    @Id
    @Column(name = "user_id", length = 8)
    private String userId;

    @Id
    @Column(name = "item_id", length = 10)
    private String itemId;

    @Column(name = "counts")
    private Integer counts;

    @ManyToOne
    @JoinColumn(name = "item_id", insertable = false, updatable = false)
    private Item item;
} 