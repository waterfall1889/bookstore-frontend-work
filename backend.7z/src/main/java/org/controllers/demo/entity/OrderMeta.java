package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.util.List;

@Data
@Entity
@Table(name = "order_meta")
public class OrderMeta {
    @Id
    @Column(name = "order_id", length = 10)
    private String orderId;

    @Column(name = "user_id", length = 8)
    private String userId;

    @Column(name = "status", length = 3)
    private String status;

    @Column(name = "date", length = 10)
    private String date;

    @OneToMany(mappedBy = "orderMeta", cascade = CascadeType.ALL)
    private List<OrderItem> orderItems;
} 