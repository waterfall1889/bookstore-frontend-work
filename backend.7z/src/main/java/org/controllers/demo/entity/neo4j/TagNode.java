package org.controllers.demo.entity.neo4j;

import org.springframework.data.neo4j.core.schema.Id;
import org.springframework.data.neo4j.core.schema.Node;
import org.springframework.data.neo4j.core.schema.Relationship;
import lombok.Data;
import java.util.HashSet;
import java.util.Set;

@Data
@Node("Tag")
public class TagNode {
    @Id
    private String name;

    private String description;

    @Relationship(type = "SUBCATEGORY_OF", direction = Relationship.Direction.OUTGOING)
    private Set<TagNode> parentTags = new HashSet<>();

    @Relationship(type = "SUBCATEGORY_OF", direction = Relationship.Direction.INCOMING)
    private Set<TagNode> childTags = new HashSet<>();

    public TagNode() {
    }

    public TagNode(String name) {
        this.name = name;
    }

    public TagNode(String name, String description) {
        this.name = name;
        this.description = description;
    }
}

