package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;

@Data
@Entity
@Table(name = "item_meta")
public class Item {
    @Id
    @Column(name = "item_id", length = 9)
    private String itemId;

    @Column(name = "item_name", length = 40)
    private String itemName;

    @Column(name = "author", length = 20)
    private String author;

    @Column(name = "remain_number")
    private Integer remainNumber;

    @Column(name = "price", precision = 10, scale = 2)
    private BigDecimal price;

    @Column(name = "cover_url", length = 2083)
    private String coverUrl;

    @Column(name = "isbn", length = 17)
    private String isbn;

    @Column(name = "publish", length = 30)
    private String publish;

    @Column(name = "validness")
    private Integer validness;
} 