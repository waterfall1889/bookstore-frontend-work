package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "cart_items")
public class Cart {
    @Id
    @Column(name = "user_id", length = 8)
    private String userId;
} 