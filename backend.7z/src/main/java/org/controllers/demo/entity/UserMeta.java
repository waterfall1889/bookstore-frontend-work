package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "users_meta")
public class UserMeta {
    @Id
    @Column(name = "id", length = 8)
    private String id;

    @Column(name = "username", length = 16)
    private String username;
} 