package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "item_comments")
public class Comment {
    @Id
    @Column(name = "comment_id", length = 10)
    private String commentId;

    @Column(name = "commenter_id", length = 8)
    private String commenterId;

    @Column(name = "item_id", length = 9)
    private String itemId;

    @Column(name = "rating")
    private Integer rating;

    @Column(name = "comment", length = 300)
    private String comment;

    @Column(name = "comment_time", length = 10)
    private String commentTime;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "commenter_id", insertable = false, updatable = false)
    private UserMeta userMeta;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "commenter_id", insertable = false, updatable = false)
    private UserProfile userProfile;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "item_id", insertable = false, updatable = false)
    private Item item;
} 