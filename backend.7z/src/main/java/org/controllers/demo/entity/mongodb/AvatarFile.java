package org.controllers.demo.entity.mongodb;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;
import java.time.LocalDateTime;

/**
 * 头像文件实体
 * 存储在MongoDB中
 */
@Data
@Document(collection = "avatars")
public class AvatarFile {
    @Id
    private String id;
    
    /**
     * 用户ID
     */
    private String userId;
    
    /**
     * 文件名
     */
    private String filename;
    
    /**
     * 文件类型（MIME类型）
     */
    private String contentType;
    
    /**
     * 文件大小（字节）
     */
    private Long fileSize;
    
    /**
     * 文件内容（Base64编码或二进制数据）
     * 注意：对于大文件，建议使用GridFS
     */
    private byte[] content;
    
    /**
     * 上传时间
     */
    private LocalDateTime uploadTime;
    
    /**
     * 是否为当前使用的头像
     */
    private Boolean isActive;
}

