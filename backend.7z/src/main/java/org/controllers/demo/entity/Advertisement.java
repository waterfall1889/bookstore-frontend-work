package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "ad_meta")
public class Advertisement {
    @Id
    @Column(length = 5)
    private String id;

    @Column(length = 300)
    private String url;
} 