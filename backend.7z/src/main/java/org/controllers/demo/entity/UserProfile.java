package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "users_profile")
public class UserProfile {
    @Id
    @Column(name = "id", length = 8)
    private String id;

    @Column(name = "email", length = 40)
    private String email;

    @Column(name = "status", length = 5)
    private String status;

    @Column(name = "register_date", length = 10)
    private String registerDate;

    @Column(name = "phone", length = 13)
    private String phone;

    @Column(name = "description", length = 200)
    private String description;

    @Column(name = "avatar_url", length = 2083)
    private String avatarUrl;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id", referencedColumnName = "id")
    private UserMeta userMeta;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id", referencedColumnName = "id")
    private UserAuth userAuth;
} 