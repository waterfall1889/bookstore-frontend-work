package org.controllers.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "book_tags")
public class BookTag {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tag_id")
    private Integer tagId;

    @Column(name = "tag_name", length = 50, unique = true, nullable = false)
    private String tagName;

    @Column(name = "description", length = 200)
    private String description;
}

