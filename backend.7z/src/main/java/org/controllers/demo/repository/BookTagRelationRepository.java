package org.controllers.demo.repository;

import org.controllers.demo.entity.BookTagRelation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookTagRelationRepository extends JpaRepository<BookTagRelation, Integer> {
    List<BookTagRelation> findByItemId(String itemId);
    List<BookTagRelation> findByTagId(Integer tagId);
    
    @Query("SELECT btr.itemId FROM BookTagRelation btr WHERE btr.tagId IN :tagIds")
    List<String> findItemIdsByTagIds(@Param("tagIds") List<Integer> tagIds);
    
    void deleteByItemId(String itemId);
    void deleteByItemIdAndTagId(String itemId, Integer tagId);
}

