package org.controllers.demo.repository;

import org.controllers.demo.entity.BookTag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookTagRepository extends JpaRepository<BookTag, Integer> {
    Optional<BookTag> findByTagName(String tagName);
    List<BookTag> findByTagNameIn(List<String> tagNames);
}

