package org.controllers.demo.repository;

import org.controllers.demo.entity.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, String> {
    @Query("SELECT DISTINCT c FROM Comment c " +
           "LEFT JOIN FETCH c.userMeta um " +
           "LEFT JOIN FETCH c.userProfile up " +
           "WHERE c.itemId = :itemId")
    List<Comment> findByItemIdWithUserInfo(@Param("itemId") String itemId);
    
    @Query("SELECT DISTINCT c FROM Comment c " +
           "LEFT JOIN FETCH c.userMeta um " +
           "LEFT JOIN FETCH c.userProfile up " +
           "WHERE c.commenterId = :commenterId")
    List<Comment> findByCommenterIdWithUserInfo(@Param("commenterId") String commenterId);
    
    @Query("SELECT AVG(c.rating) FROM Comment c WHERE c.itemId = :itemId")
    Double getAverageRatingByItemId(@Param("itemId") String itemId);
    
    @Query("SELECT DISTINCT c FROM Comment c " +
           "LEFT JOIN FETCH c.userMeta um " +
           "LEFT JOIN FETCH c.userProfile up " +
           "WHERE c.itemId = :itemId " +
           "ORDER BY c.commentTime DESC")
    List<Comment> findByItemIdOrderByCommentTimeDesc(@Param("itemId") String itemId);
} 