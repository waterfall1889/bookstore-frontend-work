package org.controllers.demo.repository;

import org.controllers.demo.entity.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemRepository extends JpaRepository<Item, String> {
    Item findByItemName(String itemName);
    List<Item> findAllByValidness(Integer validness);
    Item findByItemNameAndValidness(String itemName, Integer validness);
}