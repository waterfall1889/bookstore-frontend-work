package org.controllers.demo.repository;

import org.controllers.demo.entity.UserMeta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserMetaRepository extends JpaRepository<UserMeta, String> {
    @Query("SELECT u FROM UserMeta u WHERE u.username = :username")
    UserMeta findByUsername(@Param("username") String username);
} 