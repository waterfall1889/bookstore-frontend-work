package org.controllers.demo.repository.neo4j;

import org.controllers.demo.entity.neo4j.TagNode;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.neo4j.repository.query.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TagNodeRepository extends Neo4jRepository<TagNode, String> {
    /**
     * 根据名称查找标签，确保只返回一个结果
     * 如果存在多个同名标签，返回第一个
     */
    @Query("MATCH (t:Tag) WHERE t.name = $name RETURN t LIMIT 1")
    Optional<TagNode> findByName(@Param("name") String name);
    
    /**
     * 查找所有同名标签（用于检查重复）
     */
    @Query("MATCH (t:Tag) WHERE t.name = $name RETURN t")
    List<TagNode> findAllByName(@Param("name") String name);
    
    @Query("MATCH (t:Tag) WHERE t.name IN $names RETURN t")
    List<TagNode> findByNames(@Param("names") List<String> names);
    
    @Query("MATCH (start:Tag {name: $tagName}) " +
           "MATCH path = (start)-[:SUBCATEGORY_OF*0..2]-(related:Tag) " +
           "RETURN DISTINCT related.name AS tagName")
    List<String> findRelatedTagNames(@Param("tagName") String tagName);
    
    @Query("MATCH (start:Tag) WHERE start.name IN $tagNames " +
           "MATCH path = (start)-[:SUBCATEGORY_OF*0..2]-(related:Tag) " +
           "RETURN DISTINCT related.name AS tagName")
    List<String> findRelatedTagNamesByMultiple(@Param("tagNames") List<String> tagNames);
}

