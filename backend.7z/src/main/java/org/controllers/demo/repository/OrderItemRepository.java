package org.controllers.demo.repository;

import org.controllers.demo.entity.OrderItem;
import org.controllers.demo.entity.OrderItemId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderItemRepository extends JpaRepository<OrderItem, OrderItemId> {
    List<OrderItem> findByOrderId(String orderId);


    @Query("SELECT oi FROM OrderItem oi JOIN FETCH oi.item WHERE oi.orderId = :orderId")
    List<OrderItem> findByOrderIdWithItem(@Param("orderId") String orderId);
} 