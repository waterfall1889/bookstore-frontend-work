package org.controllers.demo.repository;

import org.controllers.demo.entity.ItemDescription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
@Repository
public interface ItemDescriptionRepository extends JpaRepository<ItemDescription, String> {
} 