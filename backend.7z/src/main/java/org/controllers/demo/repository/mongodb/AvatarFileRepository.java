package org.controllers.demo.repository.mongodb;

import org.controllers.demo.entity.mongodb.AvatarFile;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AvatarFileRepository extends MongoRepository<AvatarFile, String> {
    /**
     * 根据用户ID查找当前激活的头像
     */
    Optional<AvatarFile> findByUserIdAndIsActiveTrue(String userId);
    
    /**
     * 根据用户ID查找所有头像（包括历史头像）
     */
    java.util.List<AvatarFile> findByUserId(String userId);
    
    /**
     * 删除用户的所有头像
     */
    void deleteByUserId(String userId);
}

