package org.controllers.demo.repository;

import org.controllers.demo.entity.OrderMeta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderMetaRepository extends JpaRepository<OrderMeta, String> {
    List<OrderMeta> findByUserId(String userId);
    
    @Query("SELECT o FROM OrderMeta o WHERE o.userId = :userId AND o.date >= :startDate AND o.date <= :endDate")
    List<OrderMeta> findByUserIdAndDateBetween(
        @Param("userId") String userId,
        @Param("startDate") String startDate,
        @Param("endDate") String endDate
    );

    List<OrderMeta> findByDateBetween(
        @Param("startDate") String startDate,
        @Param("endDate") String endDate
    );
}