package org.controllers.demo.repository;

import org.controllers.demo.entity.CartItem;
import org.controllers.demo.entity.CartItemId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartItemRepository extends JpaRepository<CartItem, CartItemId> {
    List<CartItem> findByUserId(String userId);
    
    @Query("SELECT c FROM CartItem c WHERE c.userId = :userId AND c.itemId = :itemId")
    CartItem findByUserIdAndItemId(@Param("userId") String userId, @Param("itemId") String itemId);
    
    @Modifying
    @Query("DELETE FROM CartItem c WHERE c.userId = :userId")
    void deleteByUserId(@Param("userId") String userId);
    
    @Modifying
    @Query("DELETE FROM CartItem c WHERE c.userId = :userId AND c.itemId = :itemId")
    void deleteByUserIdAndItemId(@Param("userId") String userId, @Param("itemId") String itemId);
} 