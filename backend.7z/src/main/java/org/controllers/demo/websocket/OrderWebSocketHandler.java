package org.controllers.demo.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 订单WebSocket处理器
 * 处理WebSocket连接、消息发送和接收
 */
@Component
public class OrderWebSocketHandler extends TextWebSocketHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(OrderWebSocketHandler.class);
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 使用ConcurrentHashMap存储用户ID到WebSocket会话的映射
     * ConcurrentHashMap是线程安全的，支持高并发读写操作
     * Key: userId (用户ID)
     * Value: WebSocketSession (WebSocket会话)
     */
    private static final ConcurrentHashMap<String, WebSocketSession> userSessions = new ConcurrentHashMap<>();

    /**
     * WebSocket连接建立后调用
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        // 从URI中获取用户ID参数
        String userId = getUserIdFromSession(session);
        
        if (userId != null && !userId.isEmpty()) {
            // 将用户ID和Session存入Map
            userSessions.put(userId, session);
            logger.info("WebSocket连接建立 - 用户ID: {}, Session ID: {}", userId, session.getId());
            logger.info("当前在线用户数: {}", userSessions.size());
            
            // 发送连接成功消息
            sendMessage(userId, "connection", "WebSocket连接成功", null);
        } else {
            logger.warn("WebSocket连接失败 - 未提供用户ID");
            session.close(CloseStatus.BAD_DATA.withReason("缺少用户ID参数"));
        }
    }

    /**
     * 接收到客户端消息时调用
     */
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String userId = getUserIdFromSession(session);
        logger.info("收到来自用户 {} 的消息: {}", userId, message.getPayload());
        
        try {
            // 解析客户端消息
            @SuppressWarnings("unchecked")
            Map<String, Object> payload = objectMapper.readValue(message.getPayload(), Map.class);
            String type = (String) payload.get("type");
            
            // 根据消息类型处理
            if ("ping".equals(type)) {
                // 心跳响应
                sendMessage(userId, "pong", "心跳响应", null);
            } else {
                logger.info("处理消息类型: {}", type);
            }
        } catch (Exception e) {
            logger.error("处理消息失败", e);
        }
    }

    /**
     * WebSocket连接关闭时调用
     */
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        String userId = getUserIdFromSession(session);
        if (userId != null) {
            userSessions.remove(userId);
            logger.info("WebSocket连接关闭 - 用户ID: {}, 原因: {}", userId, status);
            logger.info("当前在线用户数: {}", userSessions.size());
        }
    }

    /**
     * 传输错误时调用
     */
    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        String userId = getUserIdFromSession(session);
        logger.error("WebSocket传输错误 - 用户ID: {}", userId, exception);
        
        if (session.isOpen()) {
            session.close(CloseStatus.SERVER_ERROR);
        }
        
        if (userId != null) {
            userSessions.remove(userId);
        }
    }

    /**
     * 从Session中获取用户ID
     */
    private String getUserIdFromSession(WebSocketSession session) {
        try {
            String query = session.getUri().getQuery();
            if (query != null && query.contains("userId=")) {
                String[] params = query.split("&");
                for (String param : params) {
                    if (param.startsWith("userId=")) {
                        return param.substring(7); // "userId=".length() = 7
                    }
                }
            }
        } catch (Exception e) {
            logger.error("获取用户ID失败", e);
        }
        return null;
    }

    /**
     * 向指定用户发送订单处理结果消息
     * 这是对外暴露的核心方法，用于向特定用户推送订单消息
     * 
     * @param userId 用户ID
     * @param type 消息类型
     * @param message 消息内容
     * @param data 附加数据
     * @return 是否发送成功
     */
    public boolean sendMessage(String userId, String type, String message, Object data) {
        WebSocketSession session = userSessions.get(userId);
        
        if (session == null || !session.isOpen()) {
            logger.warn("无法发送消息 - 用户 {} 未连接或连接已关闭", userId);
            return false;
        }

        try {
            // 构建消息对象
            Map<String, Object> messageObj = new ConcurrentHashMap<>();
            messageObj.put("type", type);
            messageObj.put("message", message);
            messageObj.put("timestamp", System.currentTimeMillis());
            if (data != null) {
                messageObj.put("data", data);
            }

            // 转换为JSON并发送
            String jsonMessage = objectMapper.writeValueAsString(messageObj);
            session.sendMessage(new TextMessage(jsonMessage));
            
            logger.info("消息发送成功 - 用户ID: {}, 消息类型: {}", userId, type);
            return true;
        } catch (IOException e) {
            logger.error("发送消息失败 - 用户ID: {}", userId, e);
            
            // 发送失败时清理会话
            try {
                session.close();
            } catch (IOException ex) {
                logger.error("关闭会话失败", ex);
            }
            userSessions.remove(userId);
            
            return false;
        }
    }

    /**
     * 向指定用户发送订单处理结果
     * 
     * @param userId 用户ID
     * @param orderId 订单ID
     * @param status 订单状态
     * @param message 消息
     * @return 是否发送成功
     */
    public boolean sendOrderResult(String userId, String orderId, String status, String message) {
        Map<String, Object> orderData = new ConcurrentHashMap<>();
        orderData.put("orderId", orderId);
        orderData.put("status", status);
        orderData.put("message", message);
        
        return sendMessage(userId, "order_result", "订单处理完成", orderData);
    }

    /**
     * 获取在线用户数量
     */
    public int getOnlineUserCount() {
        return userSessions.size();
    }

    /**
     * 检查用户是否在线
     */
    public boolean isUserOnline(String userId) {
        WebSocketSession session = userSessions.get(userId);
        return session != null && session.isOpen();
    }

    /**
     * 广播消息给所有在线用户（一般不使用，此处仅作示例）
     */
    public void broadcast(String type, String message) {
        userSessions.forEach((userId, session) -> {
            if (session.isOpen()) {
                sendMessage(userId, type, message, null);
            }
        });
    }
}

