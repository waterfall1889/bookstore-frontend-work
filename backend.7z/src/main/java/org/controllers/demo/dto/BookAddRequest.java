package org.controllers.demo.dto;

import java.math.BigDecimal;
import lombok.Data;

@Data
public class BookAddRequest {
    private String itemId;
    private String itemName;
    private BigDecimal price;
    private String publish;
    private String author;
    private Integer remainNumber;
    private String isbn;
    private String coverUrl;
    private String description;
    private Integer validness;
} 