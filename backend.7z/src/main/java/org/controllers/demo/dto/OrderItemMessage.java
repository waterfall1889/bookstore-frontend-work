package org.controllers.demo.dto;

/**
 * 订单项消息格式
 */
public class OrderItemMessage {
    private String itemId;
    private int counts;
    private String itemName;
    private double price;

    // 构造函数
    public OrderItemMessage() {}

    public OrderItemMessage(String itemId, int counts, String itemName, double price) {
        this.itemId = itemId;
        this.counts = counts;
        this.itemName = itemName;
        this.price = price;
    }

    // Getter和Setter方法
    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }

    public int getCounts() { return counts; }
    public void setCounts(int counts) { this.counts = counts; }

    public String getItemName() { return itemName; }
    public void setItemName(String itemName) { this.itemName = itemName; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString() {
        return "OrderItemMessage{" +
                "itemId='" + itemId + '\'' +
                ", counts=" + counts +
                ", itemName='" + itemName + '\'' +
                ", price=" + price +
                '}';
    }
}