package org.controllers.demo.dto;

import java.util.List;

/**
 * 订单消息格式
 * 用于Kafka消息传递
 */
public class OrderMessage {
    private String messageId;
    private String userId;
    private String orderId;
    private String timestamp;
    private List<OrderItemMessage> items;
    private String status;

    // 构造函数
    public OrderMessage() {}

    public OrderMessage(String messageId, String userId, String orderId, String timestamp,
                        List<OrderItemMessage> items, String status) {
        this.messageId = messageId;
        this.userId = userId;
        this.orderId = orderId;
        this.timestamp = timestamp;
        this.items = items;
        this.status = status;
    }

    // Getter和Setter方法
    public String getMessageId() { return messageId; }
    public void setMessageId(String messageId) { this.messageId = messageId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public List<OrderItemMessage> getItems() { return items; }
    public void setItems(List<OrderItemMessage> items) { this.items = items; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "OrderMessage{" +
                "messageId='" + messageId + '\'' +
                ", userId='" + userId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", items=" + items +
                ", status='" + status + '\'' +
                '}';
    }
}