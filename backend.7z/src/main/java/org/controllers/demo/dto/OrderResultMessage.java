package org.controllers.demo.dto;

/**
 * 订单处理结果消息格式
 */
public class OrderResultMessage {
    private String messageId;
    private String orderId;
    private String userId;
    private String status;
    private String result;
    private String timestamp;
    private String errorMessage;

    // 构造函数
    public OrderResultMessage() {}

    public OrderResultMessage(String messageId, String orderId, String userId,
                              String status, String result, String timestamp, String errorMessage) {
        this.messageId = messageId;
        this.orderId = orderId;
        this.userId = userId;
        this.status = status;
        this.result = result;
        this.timestamp = timestamp;
        this.errorMessage = errorMessage;
    }

    // Getter和Setter方法
    public String getMessageId() { return messageId; }
    public void setMessageId(String messageId) { this.messageId = messageId; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }

    @Override
    public String toString() {
        return "OrderResultMessage{" +
                "messageId='" + messageId + '\'' +
                ", orderId='" + orderId + '\'' +
                ", userId='" + userId + '\'' +
                ", status='" + status + '\'' +
                ", result='" + result + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }
}