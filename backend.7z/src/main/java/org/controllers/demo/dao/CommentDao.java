package org.controllers.demo.dao;

import org.controllers.demo.entity.Comment;
import java.util.List;

public interface CommentDao {
    Comment findById(String id);
    List<Comment> findByItemId(String itemId);
    List<Comment> findByCommenterId(String commenterId);
    Comment save(Comment comment);
    void deleteById(String id);
} 