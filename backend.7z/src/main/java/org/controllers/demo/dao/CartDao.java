package org.controllers.demo.dao;

import org.controllers.demo.entity.CartItem;
import java.util.List;

public interface CartDao {
    List<CartItem> findByUserId(String userId);
    CartItem findByUserIdAndItemId(String userId, String itemId);
    CartItem save(CartItem cartItem);
    void deleteByUserId(String userId);
    void deleteByUserIdAndItemId(String userId, String itemId);
} 