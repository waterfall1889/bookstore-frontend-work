package org.controllers.demo.dao.impl;

import org.controllers.demo.dao.CartDao;
import org.controllers.demo.entity.CartItem;
import org.controllers.demo.entity.CartItemId;
import org.controllers.demo.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class CartDaoImpl implements CartDao {
    @Autowired
    private CartItemRepository cartItemRepository;

    @Override
    public List<CartItem> findByUserId(String userId) {
        return cartItemRepository.findByUserId(userId);
    }

    @Override
    public CartItem findByUserIdAndItemId(String userId, String itemId) {
        return cartItemRepository.findByUserIdAndItemId(userId, itemId);
    }

    @Override
    public CartItem save(CartItem cartItem) {
        return cartItemRepository.save(cartItem);
    }

    @Override
    @Transactional
    public void deleteByUserId(String userId) {
        cartItemRepository.deleteByUserId(userId);
    }

    @Override
    @Transactional
    public void deleteByUserIdAndItemId(String userId, String itemId) {
        cartItemRepository.deleteByUserIdAndItemId(userId, itemId);
    }
} 