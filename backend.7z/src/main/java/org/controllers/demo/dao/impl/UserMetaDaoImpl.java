package org.controllers.demo.dao.impl;

import org.controllers.demo.dao.UserMetaDao;
import org.controllers.demo.entity.UserMeta;
import org.controllers.demo.repository.UserMetaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserMetaDaoImpl implements UserMetaDao {
    @Autowired
    private UserMetaRepository userMetaRepository;

    @Override
    public UserMeta findById(String id) {
        return userMetaRepository.findById(id).orElse(null);
    }

    @Override
    public UserMeta findByUsername(String username) {
        return userMetaRepository.findByUsername(username);
    }

    @Override
    public UserMeta save(UserMeta userMeta) {
        return userMetaRepository.save(userMeta);
    }
} 