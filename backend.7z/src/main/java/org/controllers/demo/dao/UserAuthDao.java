package org.controllers.demo.dao;

import org.controllers.demo.entity.UserAuth;

public interface UserAuthDao {
    UserAuth findById(String id);
    UserAuth save(UserAuth userAuth);
} 