package org.controllers.demo.dao.impl;

import org.controllers.demo.dao.OrderDao;
import org.controllers.demo.entity.OrderMeta;
import org.controllers.demo.entity.OrderItem;
import org.controllers.demo.repository.OrderMetaRepository;
import org.controllers.demo.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class OrderDaoImpl implements OrderDao {
    @Autowired
    private OrderMetaRepository orderMetaRepository;
    @Autowired
    private OrderItemRepository orderItemRepository;

    @Override
    public OrderMeta saveOrderMeta(OrderMeta orderMeta) {
        return orderMetaRepository.save(orderMeta);
    }

    @Override
    public List<OrderMeta> findOrdersByUserId(String userId) {
        return orderMetaRepository.findByUserId(userId);
    }

    @Override
    public OrderMeta findOrderById(String orderId) {
        return orderMetaRepository.findById(orderId).orElse(null);
    }

    @Override
    @Transactional
    public void updateOrderStatus(String orderId, String status) {
        OrderMeta order = orderMetaRepository.findById(orderId).orElse(null);
        if (order != null) {
            order.setStatus(status);
            orderMetaRepository.save(order);
        }
    }

    @Override
    public List<OrderMeta> findOrdersByUserIdAndDateBetween(String userId, String startDate, String endDate) {
        return orderMetaRepository.findByUserIdAndDateBetween(userId, startDate, endDate);
    }

    @Override
    public List<OrderMeta> findAllOrdersAndDateBetween(String startDate, String endDate) {
        return orderMetaRepository.findByDateBetween(startDate, endDate);
    }

    @Override
    public List<OrderItem> findOrderItemsByOrderId(String orderId) {
        return orderItemRepository.findByOrderId(orderId);
    }


    @Override
    public OrderItem saveOrderItem(OrderItem orderItem) {
        return orderItemRepository.save(orderItem);
    }

    @Override
    public List<OrderMeta> findAllOrders() {
        // 使用 Spring Data JPA 的 findAll() 方法获取所有订单
        return orderMetaRepository.findAll();
    }
} 