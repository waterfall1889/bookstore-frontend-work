package org.controllers.demo.dao.impl;

import org.controllers.demo.cache.BookCacheService;
import org.controllers.demo.dao.ItemDao;
import org.controllers.demo.entity.Item;
import org.controllers.demo.repository.ItemRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ItemDaoImpl implements ItemDao {
    private static final Logger logger = LoggerFactory.getLogger(ItemDaoImpl.class);
    
    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired
    private BookCacheService bookCacheService;

    @Override
    public Item findById(String itemId) {
        logger.info("[ItemDao] ========== 开始查询图书 ========== - itemId: {}", itemId);
        
        // 1. 先从缓存读取
        logger.debug("[ItemDao] 步骤1: 尝试从Redis缓存读取 - itemId: {}", itemId);
        Item cachedItem = bookCacheService.getBook(itemId);
        if (cachedItem != null) {
            logger.info("[ItemDao] ✅ 缓存命中！从Redis缓存获取图书成功 - itemId: {}, 书名: {}, 库存: {}", 
                itemId, cachedItem.getItemName(), cachedItem.getRemainNumber());
            logger.info("[ItemDao] ========== 查询完成（缓存） ==========");
            return cachedItem;
        }
        
        // 2. 缓存未命中，从数据库读取
        logger.info("[ItemDao] ⚠️ 缓存未命中，降级到数据库查询 - itemId: {}", itemId);
        logger.debug("[ItemDao] 步骤2: 从MySQL数据库查询 - itemId: {}", itemId);
        Item item = itemRepository.findById(itemId).orElse(null);
        
        // 3. 如果数据库查询成功，写入缓存
        if (item != null) {
            logger.info("[ItemDao] ✅ 从数据库查询图书成功 - itemId: {}, 书名: {}, 库存: {}", 
                itemId, item.getItemName(), item.getRemainNumber());
            logger.debug("[ItemDao] 步骤3: 将数据写入Redis缓存 - itemId: {}", itemId);
            bookCacheService.setBook(item);
            logger.info("[ItemDao] ✅ 数据已写入缓存，下次查询将命中缓存 - itemId: {}", itemId);
        } else {
            logger.warn("[ItemDao] ❌ 数据库中未找到图书 - itemId: {}", itemId);
        }
        
        logger.info("[ItemDao] ========== 查询完成（数据库） ==========");
        return item;
    }

    @Override
    public List<Item> findAll() {
        logger.info("开始查询所有图书");
        // 查询所有图书时，直接从数据库读取，不进行缓存（因为数据量大，不适合全部缓存）
        List<Item> items = itemRepository.findAll();
        logger.info("查询所有图书完成，数量: {}", items != null ? items.size() : 0);
        return items;
    }

    @Override
    public Item save(Item item) {
        logger.info("[ItemDao] ========== 开始保存/更新图书 ========== - itemId: {}", 
            item != null ? item.getItemId() : "null");
        
        // 1. 保存到数据库
        logger.debug("[ItemDao] 步骤1: 保存到MySQL数据库 - itemId: {}", 
            item != null ? item.getItemId() : "null");
        Item savedItem = itemRepository.save(item);
        logger.info("[ItemDao] ✅ 保存图书到数据库成功 - itemId: {}, 书名: {}, 库存: {}", 
            savedItem != null ? savedItem.getItemId() : "null",
            savedItem != null ? savedItem.getItemName() : "null",
            savedItem != null ? savedItem.getRemainNumber() : "null");
        
        // 2. 更新缓存（写操作后同步缓存）
        if (savedItem != null) {
            logger.debug("[ItemDao] 步骤2: 同步更新Redis缓存 - itemId: {}", savedItem.getItemId());
            bookCacheService.setBook(savedItem);
            // 删除列表缓存，因为列表可能已变化
            logger.debug("[ItemDao] 步骤3: 删除图书列表缓存（因为列表可能已变化）");
            bookCacheService.deleteBookList();
            logger.info("[ItemDao] ✅ Redis缓存更新完成 - itemId: {}", savedItem.getItemId());
        }
        
        logger.info("[ItemDao] ========== 保存/更新完成 ==========");
        return savedItem;
    }

    @Override
    public void deleteById(String itemId) {
        logger.info("[ItemDao] ========== 开始删除图书 ========== - itemId: {}", itemId);
        
        // 1. 从数据库删除
        logger.debug("[ItemDao] 步骤1: 从MySQL数据库删除 - itemId: {}", itemId);
        itemRepository.deleteById(itemId);
        logger.info("[ItemDao] ✅ 从数据库删除图书成功 - itemId: {}", itemId);
        
        // 2. 从缓存删除
        logger.debug("[ItemDao] 步骤2: 从Redis缓存删除 - itemId: {}", itemId);
        bookCacheService.deleteBook(itemId);
        
        // 3. 删除列表缓存
        logger.debug("[ItemDao] 步骤3: 删除图书列表缓存 - itemId: {}", itemId);
        bookCacheService.deleteBookList();
        
        logger.info("[ItemDao] ✅ Redis缓存删除完成 - itemId: {}", itemId);
        logger.info("[ItemDao] ========== 删除完成 ==========");
    }
} 