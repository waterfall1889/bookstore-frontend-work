package org.controllers.demo.dao;

import org.controllers.demo.entity.UserProfile;
import java.util.List;

public interface UserProfileDao {
    UserProfile findById(String id);
    UserProfile findByIdWithUserMeta(String id);
    List<UserProfile> findAll();
    UserProfile save(UserProfile userProfile);
} 