package org.controllers.demo.dao;

import org.controllers.demo.entity.UserMeta;

public interface UserMetaDao {
    UserMeta findById(String id);
    UserMeta findByUsername(String username);
    UserMeta save(UserMeta userMeta);
} 