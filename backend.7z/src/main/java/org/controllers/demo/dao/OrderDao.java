package org.controllers.demo.dao;

import org.controllers.demo.entity.OrderMeta;
import org.controllers.demo.entity.OrderItem;
import java.util.List;

public interface OrderDao {
    OrderMeta saveOrderMeta(OrderMeta orderMeta);
    List<OrderMeta> findOrdersByUserId(String userId);
    OrderMeta findOrderById(String orderId);
    void updateOrderStatus(String orderId, String status);
    List<OrderMeta> findOrdersByUserIdAndDateBetween(String userId, String startDate, String endDate);
    List<OrderMeta> findAllOrdersAndDateBetween(String startDate, String endDate);

    List<OrderItem> findOrderItemsByOrderId(String orderId);
    OrderItem saveOrderItem(OrderItem orderItem);
    List<OrderMeta> findAllOrders();
} 