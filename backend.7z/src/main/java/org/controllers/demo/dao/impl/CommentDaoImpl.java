package org.controllers.demo.dao.impl;

import org.controllers.demo.dao.CommentDao;
import org.controllers.demo.entity.Comment;
import org.controllers.demo.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CommentDaoImpl implements CommentDao {
    @Autowired
    private CommentRepository commentRepository;

    @Override
    public Comment findById(String id) {
        return commentRepository.findById(id).orElse(null);
    }

    @Override
    public List<Comment> findByItemId(String itemId) {
        return commentRepository.findByItemIdWithUserInfo(itemId);
    }

    @Override
    public List<Comment> findByCommenterId(String commenterId) {
        return commentRepository.findByCommenterIdWithUserInfo(commenterId);
    }

    @Override
    public Comment save(Comment comment) {
        return commentRepository.save(comment);
    }

    @Override
    public void deleteById(String id) {
        commentRepository.deleteById(id);
    }
} 