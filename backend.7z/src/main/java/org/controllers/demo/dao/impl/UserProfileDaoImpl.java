package org.controllers.demo.dao.impl;

import org.controllers.demo.dao.UserProfileDao;
import org.controllers.demo.entity.UserProfile;
import org.controllers.demo.repository.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserProfileDaoImpl implements UserProfileDao {
    @Autowired
    private UserProfileRepository userProfileRepository;

    @Override
    public UserProfile findById(String id) {
        return userProfileRepository.findById(id).orElse(null);
    }

    @Override
    public UserProfile findByIdWithUserMeta(String id) {
        return userProfileRepository.findByIdWithUserMeta(id);
    }

    @Override
    public List<UserProfile> findAll() {
        return userProfileRepository.findAll();
    }

    @Override
    public UserProfile save(UserProfile userProfile) {
        return userProfileRepository.save(userProfile);
    }
} 