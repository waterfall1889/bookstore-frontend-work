package org.controllers.demo.dao.impl;

import org.controllers.demo.dao.UserAuthDao;
import org.controllers.demo.entity.UserAuth;
import org.controllers.demo.repository.UserAuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserAuthDaoImpl implements UserAuthDao {
    @Autowired
    private UserAuthRepository userAuthRepository;

    @Override
    public UserAuth findById(String id) {
        return userAuthRepository.findById(id).orElse(null);
    }

    @Override
    public UserAuth save(UserAuth userAuth) {
        return userAuthRepository.save(userAuth);
    }
} 