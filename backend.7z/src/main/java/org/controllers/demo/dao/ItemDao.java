package org.controllers.demo.dao;

import org.controllers.demo.entity.Item;
import java.util.List;

public interface ItemDao {
    Item findById(String itemId);
    List<Item> findAll();
    Item save(Item item);
    void deleteById(String itemId);
} 