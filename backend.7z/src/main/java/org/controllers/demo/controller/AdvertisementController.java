package org.controllers.demo.controller;

import org.controllers.demo.entity.Advertisement;
import org.controllers.demo.service.AdvertisementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/advertisements")
@CrossOrigin(origins = "*")
public class AdvertisementController {

    @Autowired
    private AdvertisementService service;

    @GetMapping
    public ResponseEntity<List<Advertisement>> findAll() {
        System.out.println("AdvertisementController.findAll");
        try {
            List<Advertisement> advertisements = service.findAll();
            return ResponseEntity.ok(advertisements);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Advertisement> findById(@PathVariable String id) {
        try {
            Advertisement advertisement = service.findById(id);
            if (advertisement == null) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(advertisement);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    @PostMapping
    public ResponseEntity<Advertisement> save(@RequestBody Advertisement advertisement) {
        try {
            Advertisement saved = service.save(advertisement);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable String id) {
        try {
            service.deleteById(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }
} 