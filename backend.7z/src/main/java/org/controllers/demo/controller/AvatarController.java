package org.controllers.demo.controller;

import org.controllers.demo.entity.mongodb.AvatarFile;
import org.controllers.demo.service.AvatarService;
import org.controllers.demo.service.UserProfileService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

/**
 * 头像控制器
 * 处理头像的上传、获取和删除
 */
@RestController
@RequestMapping("/api/avatar")
@CrossOrigin(origins = "*")
public class AvatarController {
    private static final Logger logger = LoggerFactory.getLogger(AvatarController.class);

    @Autowired
    private AvatarService avatarService;

    @Autowired
    private UserProfileService userProfileService;

    /**
     * 上传用户头像
     */
    @PostMapping("/upload/{userId}")
    public ResponseEntity<?> uploadAvatar(
            @PathVariable String userId,
            @RequestParam("file") MultipartFile file) {
        try {
            logger.info("收到头像上传请求 - 用户ID: {}, 文件名: {}", userId, file.getOriginalFilename());
            
            if (file.isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "文件不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            // 上传头像到MongoDB
            String avatarUrl = avatarService.uploadAvatar(userId, file);
            
            // 更新用户档案中的头像URL
            userProfileService.updateAvatar(userId, avatarUrl);
            
            Map<String, Object> response = new HashMap<>();
            response.put("message", "头像上传成功");
            response.put("avatarUrl", avatarUrl);
            response.put("avatarId", avatarUrl.substring(avatarUrl.lastIndexOf("/") + 1));
            
            logger.info("头像上传成功 - 用户ID: {}, 头像URL: {}", userId, avatarUrl);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            logger.warn("头像上传失败 - 用户ID: {}, 错误: {}", userId, e.getMessage());
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        } catch (Exception e) {
            logger.error("头像上传失败 - 用户ID: {}", userId, e);
            Map<String, String> error = new HashMap<>();
            error.put("error", "头像上传失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 根据头像ID获取头像图片
     */
    @GetMapping("/{avatarId}")
    public ResponseEntity<byte[]> getAvatar(@PathVariable String avatarId) {
        try {
            logger.debug("获取头像 - 头像ID: {}", avatarId);
            
            AvatarFile avatar = avatarService.getAvatarById(avatarId);
            if (avatar == null || avatar.getContent() == null) {
                logger.warn("头像不存在或内容为空 - 头像ID: {}", avatarId);
                return ResponseEntity.notFound().build();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType(avatar.getContentType()));
            headers.setContentLength(avatar.getFileSize());
            headers.setCacheControl("public, max-age=3600"); // 缓存1小时

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(avatar.getContent());
        } catch (Exception e) {
            logger.error("获取头像失败 - 头像ID: {}", avatarId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 根据用户ID获取当前激活的头像
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<byte[]> getUserAvatar(@PathVariable String userId) {
        try {
            logger.debug("获取用户头像 - 用户ID: {}", userId);
            
            AvatarFile avatar = avatarService.getActiveAvatarByUserId(userId);
            if (avatar == null || avatar.getContent() == null) {
                logger.debug("用户没有头像 - 用户ID: {}", userId);
                return ResponseEntity.notFound().build();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType(avatar.getContentType()));
            headers.setContentLength(avatar.getFileSize());
            headers.setCacheControl("public, max-age=3600");

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(avatar.getContent());
        } catch (Exception e) {
            logger.error("获取用户头像失败 - 用户ID: {}", userId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * 获取头像的Base64数据URL（用于前端直接显示）
     */
    @GetMapping("/data/{userId}")
    public ResponseEntity<?> getAvatarDataUrl(@PathVariable String userId) {
        try {
            logger.debug("获取头像数据URL - 用户ID: {}", userId);
            
            String dataUrl = avatarService.getAvatarDataUrl(userId);
            if (dataUrl == null) {
                Map<String, String> response = new HashMap<>();
                response.put("avatarUrl", null);
                return ResponseEntity.ok(response);
            }

            Map<String, String> response = new HashMap<>();
            response.put("avatarUrl", dataUrl);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("获取头像数据URL失败 - 用户ID: {}", userId, e);
            Map<String, String> error = new HashMap<>();
            error.put("error", "获取头像失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }

    /**
     * 删除用户头像
     */
    @DeleteMapping("/user/{userId}")
    public ResponseEntity<?> deleteUserAvatar(@PathVariable String userId) {
        try {
            logger.info("删除用户头像 - 用户ID: {}", userId);
            
            avatarService.deleteUserAvatars(userId);
            // 更新用户档案，将头像URL设为默认值
            userProfileService.updateAvatar(userId, "http://localhost:8080/images/default.png");
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "头像删除成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("删除用户头像失败 - 用户ID: {}", userId, e);
            Map<String, String> error = new HashMap<>();
            error.put("error", "删除头像失败: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);
        }
    }
}

