package org.controllers.demo.controller;

import org.controllers.demo.entity.ItemDescription;
import org.controllers.demo.repository.ItemDescriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ItemDescriptionController {

    @Autowired
    private ItemDescriptionRepository itemDescriptionRepository;

    @GetMapping("/bookDescription/{bookId}")
    public ResponseEntity<?> getBookDescription(@PathVariable String bookId) {
        try {
            ItemDescription description = itemDescriptionRepository.findById(bookId).orElse(null);
            
            if (description == null) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "未找到该书籍的简介");
                return ResponseEntity.badRequest().body(error);
            }

            Map<String, String> response = new HashMap<>();
            response.put("description", description.getDescription());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "获取书籍简介失败：" + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 