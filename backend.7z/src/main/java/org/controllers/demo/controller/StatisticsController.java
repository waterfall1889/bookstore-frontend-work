package org.controllers.demo.controller;

import org.controllers.demo.service.StatisticsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/statistics")
@CrossOrigin(origins = "*")
public class StatisticsController {
    private static final Logger logger = LoggerFactory.getLogger(StatisticsController.class);

    @Autowired
    private StatisticsService statisticsService;

    @PostMapping("/user")
    public ResponseEntity<?> getUserStatistics(@RequestBody Map<String, String> request) {
        try {
            logger.info("收到统计请求: {}", request);
            
            String userId = request.get("Id");
            String startDate = request.get("startDate");
            String endDate = request.get("endDate");

            if (userId == null || startDate == null || endDate == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "参数不完整");
                return ResponseEntity.badRequest().body(error);
            }

            Map<String, Object> statistics = statisticsService.getUserStatistics(userId, startDate, endDate);
            logger.info("返回统计结果: {}", statistics);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            logger.error("获取统计数据时发生错误", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "获取统计数据失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/admin")
    public ResponseEntity<?> getAllStatistics(@RequestBody Map<String, String> request) {
        try {
            logger.info("收到统计请求: {}", request);
            String startDate = request.get("startDate");
            String endDate = request.get("endDate");

            if (startDate == null || endDate == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "参数不完整");
                return ResponseEntity.badRequest().body(error);
            }

            Map<String, Object> statistics = statisticsService.getAllStatistics(startDate, endDate);
            logger.info("返回统计结果: {}", statistics);

            return ResponseEntity.ok(statistics);
        }

        catch (Exception e) {
            logger.error("获取统计数据时发生错误", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "获取统计数据失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 