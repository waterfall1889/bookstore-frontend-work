package org.controllers.demo.controller;

import org.controllers.demo.service.BookTagService;
import org.controllers.demo.service.Neo4jTagService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/tags")
@CrossOrigin(origins = "*")
public class TagController {
    private static final Logger logger = LoggerFactory.getLogger(TagController.class);

    @Autowired
    private Neo4jTagService neo4jTagService;

    @Autowired
    private BookTagService bookTagService;

    /**
     * 初始化Neo4J标签关系图
     */
    @PostMapping("/init-graph")
    public ResponseEntity<?> initializeTagGraph() {
        try {
            logger.info("开始初始化标签关系图...");
            neo4jTagService.initializeTagGraph();
            Map<String, String> result = new HashMap<>();
            result.put("message", "标签关系图初始化成功");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("初始化标签关系图失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "初始化标签关系图失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 同步MySQL标签到Neo4J
     */
    @PostMapping("/sync-to-neo4j")
    public ResponseEntity<?> syncTagsToNeo4j() {
        try {
            logger.info("开始同步MySQL标签到Neo4J...");
            var tags = bookTagService.getAllTags();
            for (var tag : tags) {
                neo4jTagService.createOrUpdateTag(tag.getTagName(), tag.getDescription());
            }
            Map<String, String> result = new HashMap<>();
            result.put("message", "标签同步成功，共同步 " + tags.size() + " 个标签");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("同步标签到Neo4J失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "同步标签到Neo4J失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
}

