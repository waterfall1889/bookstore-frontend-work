package org.controllers.demo.controller;

import org.controllers.demo.entity.Item;
import org.controllers.demo.entity.ItemDescription;
import org.controllers.demo.service.BookService;
import org.controllers.demo.repository.ItemRepository;
import org.controllers.demo.repository.ItemDescriptionRepository;
import org.controllers.demo.dao.ItemDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.util.StringUtils;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

import java.util.stream.Collectors;
import java.math.BigDecimal;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.controllers.demo.dto.BookAddRequest;
import org.controllers.demo.service.BookTagService;
import org.controllers.demo.service.Neo4jTagService;
import org.controllers.demo.entity.BookTag;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class BookController {
    private static final Logger logger = LoggerFactory.getLogger(BookController.class);

    @Autowired
    private BookService bookService;

    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired
    private ItemDao itemDao;

    @Autowired
    private ItemDescriptionRepository itemDescriptionRepository;

    @Autowired
    private BookTagService bookTagService;

    @Autowired
    private Neo4jTagService neo4jTagService;

    @GetMapping("/books")
    public ResponseEntity<?> getAllBooks() {
        try {
            List<Item> books = bookService.getAllBooks();
            List<Map<String, Object>> bookList = books.stream()
                .map(book -> {
                    Map<String, Object> bookMap = new HashMap<>();
                    bookMap.put("itemId", book.getItemId());
                    bookMap.put("itemName", book.getItemName());
                    bookMap.put("author", book.getAuthor());
                    bookMap.put("remainNumber", book.getRemainNumber());
                    bookMap.put("price", book.getPrice());
                    bookMap.put("coverUrl", book.getCoverUrl());
                    bookMap.put("isbn", book.getIsbn());
                    bookMap.put("publish", book.getPublish());
                    return bookMap;
                })
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(bookList);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "加载书籍失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/books/{bookId}")
    public ResponseEntity<?> getBook(@PathVariable String bookId) {
        try {
            Item book = bookService.getBookById(bookId);
            if (book == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "书籍不存在");
                return ResponseEntity.badRequest().body(error);
            }

            Map<String, Object> bookMap = new HashMap<>();
            bookMap.put("itemId", book.getItemId());
            bookMap.put("itemName", book.getItemName());
            bookMap.put("author", book.getAuthor());
            bookMap.put("remainNumber", book.getRemainNumber());
            bookMap.put("price", book.getPrice());
            bookMap.put("coverUrl", book.getCoverUrl());
            bookMap.put("isbn", book.getIsbn());
            bookMap.put("publish", book.getPublish());
            
            return ResponseEntity.ok(bookMap);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "加载书籍失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/books/search")
    public ResponseEntity<?> searchBooks(@RequestBody Map<String, String> request) {
        try {
            logger.info("收到搜索请求，请求体: {}", request);
            
            String bookName = request.get("bookName");
            logger.info("搜索书名: {}", bookName);
            
            if (bookName == null || bookName.trim().isEmpty()) {
                logger.warn("搜索书名为空");
                Map<String, String> error = new HashMap<>();
                error.put("message", "搜索书名不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            Item book = bookService.getBookByName(bookName.trim());
            logger.info("搜索结果: {}", book);
            
            if (book == null) {
                logger.warn("未找到相关书籍: {}", bookName);
                Map<String, String> error = new HashMap<>();
                error.put("message", "未找到相关书籍");
                return ResponseEntity.badRequest().body(error);
            }

            Map<String, Object> bookMap = new HashMap<>();
            bookMap.put("itemId", book.getItemId());
            bookMap.put("itemName", book.getItemName());
            bookMap.put("author", book.getAuthor());
            bookMap.put("remainNumber", book.getRemainNumber());
            bookMap.put("price", book.getPrice());
            bookMap.put("coverUrl", book.getCoverUrl());
            bookMap.put("isbn", book.getIsbn());
            bookMap.put("publish", book.getPublish());
            
            logger.info("返回搜索结果: {}", bookMap);
            return ResponseEntity.ok(bookMap);
        } catch (Exception e) {
            logger.error("搜索书籍时发生错误", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "搜索书籍失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/upload/image")
    public ResponseEntity<?> uploadBookImage(@RequestParam("image") MultipartFile file, @RequestParam("itemId") String itemId) {
        if (file.isEmpty()) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "未选择文件");
            return ResponseEntity.badRequest().body(error);
        }
        try {
            String originalFilename = StringUtils.cleanPath(file.getOriginalFilename());
            String fileExtension = "";
            int dotIndex = originalFilename.lastIndexOf('.');
            if (dotIndex > 0) {
                fileExtension = originalFilename.substring(dotIndex);
            }
            String newFilename = "book" + itemId + fileExtension;
            String uploadDir = "F:/idea/test-web/src/main/resources/static/images/";
            File dir = new File(uploadDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            Path savePath = Paths.get(uploadDir, newFilename);
            Files.copy(file.getInputStream(), savePath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            Map<String, String> result = new HashMap<>();
            result.put("imageUrl", "/images/" + newFilename);
            return ResponseEntity.ok(result);
        } catch (IOException e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "图片上传失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/addBooks")
    public ResponseEntity<?> addBook(@RequestBody BookAddRequest request) {
        try {
            logger.info("收到添加图书请求: {}", request);
            logger.info("itemId: {}", request.getItemId());
            logger.info("itemName: {}", request.getItemName());
            logger.info("price: {}", request.getPrice());
            logger.info("publish: {}", request.getPublish());
            logger.info("author: {}", request.getAuthor());
            logger.info("remainNumber: {}", request.getRemainNumber());
            logger.info("isbn: {}", request.getIsbn());
            logger.info("coverUrl: {}", request.getCoverUrl());
            logger.info("description: {}", request.getDescription());
            Item item = new Item();
            item.setItemId(request.getItemId());
            item.setItemName(request.getItemName());
            item.setPrice(request.getPrice());
            item.setPublish(request.getPublish());
            item.setAuthor(request.getAuthor());
            item.setRemainNumber(request.getRemainNumber());
            item.setIsbn(request.getIsbn());
            item.setCoverUrl(request.getCoverUrl());
            item.setValidness(1);
            ItemDescription itemDescription = new ItemDescription();
            itemDescription.setItemId(request.getItemId());
            itemDescription.setDescription(request.getDescription());
            // 使用ItemDao保存，会自动更新缓存
            logger.info("保存新图书到数据库并同步缓存 - itemId: {}", item.getItemId());
            itemDao.save(item);
            itemDescriptionRepository.save(itemDescription);
            Map<String, String> result = new HashMap<>();
            result.put("message", "添加图书成功");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("添加图书失败，异常信息：", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "添加图书失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PutMapping("/updateBooks")
    public ResponseEntity<?> updateBook(@RequestBody BookAddRequest request) {
        try {
            logger.info("收到修改图书请求: {}", request);
            // 1. 查询并更新 Item
            Optional<Item> optionalItem = itemRepository.findById(request.getItemId());
            if (!optionalItem.isPresent()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "未找到对应的图书");
                return ResponseEntity.badRequest().body(error);
            }
            Item item = optionalItem.get();
            item.setItemName(request.getItemName());
            item.setPrice(request.getPrice());
            item.setPublish(request.getPublish());
            item.setAuthor(request.getAuthor());
            item.setRemainNumber(request.getRemainNumber());
            item.setIsbn(request.getIsbn());
            item.setCoverUrl(request.getCoverUrl());
            // 支持下架逻辑
            if (request.getValidness() != null) {
                item.setValidness(request.getValidness());
            }
            // 使用ItemDao保存，会自动更新缓存
            logger.info("保存图书更新到数据库并同步缓存 - itemId: {}", item.getItemId());
            itemDao.save(item);
            // 2. 查询并更新 ItemDescription
            Optional<ItemDescription> optionalDesc = itemDescriptionRepository.findById(request.getItemId());
            ItemDescription itemDescription = optionalDesc.orElseGet(() -> {
                ItemDescription desc = new ItemDescription();
                desc.setItemId(request.getItemId());
                return desc;
            });
            itemDescription.setDescription(request.getDescription());
            itemDescriptionRepository.save(itemDescription);
            Map<String, String> result = new HashMap<>();
            result.put("message", "修改图书成功");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("修改图书失败，异常信息：", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "修改图书失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 根据标签搜索图书
     */
    @PostMapping("/books/searchByTag")
    public ResponseEntity<?> searchBooksByTag(@RequestBody Map<String, Object> request) {
        try {
            logger.info("收到标签搜索请求，请求体: {}", request);
            
            Object tagObj = request.get("tagName");
            if (tagObj == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "标签名称不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            String tagName = tagObj.toString().trim();
            if (tagName.isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "标签名称不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            List<Item> books = bookTagService.searchBooksByTag(tagName);
            logger.info("标签搜索完成，找到 {} 本图书", books.size());

            List<Map<String, Object>> bookList = books.stream()
                .map(book -> {
                    Map<String, Object> bookMap = new HashMap<>();
                    bookMap.put("itemId", book.getItemId());
                    bookMap.put("itemName", book.getItemName());
                    bookMap.put("author", book.getAuthor());
                    bookMap.put("remainNumber", book.getRemainNumber());
                    bookMap.put("price", book.getPrice());
                    bookMap.put("coverUrl", book.getCoverUrl());
                    bookMap.put("isbn", book.getIsbn());
                    bookMap.put("publish", book.getPublish());
                    // 获取图书的标签
                    List<BookTag> tags = bookTagService.getBookTags(book.getItemId());
                    List<String> tagNames = tags.stream()
                            .map(BookTag::getTagName)
                            .collect(Collectors.toList());
                    bookMap.put("tags", tagNames);
                    return bookMap;
                })
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(bookList);
        } catch (Exception e) {
            logger.error("标签搜索失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "标签搜索失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 根据多个标签搜索图书
     */
    @PostMapping("/books/searchByTags")
    public ResponseEntity<?> searchBooksByTags(@RequestBody Map<String, Object> request) {
        try {
            logger.info("收到多标签搜索请求，请求体: {}", request);
            
            @SuppressWarnings("unchecked")
            List<String> tagNames = (List<String>) request.get("tagNames");
            if (tagNames == null || tagNames.isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "标签名称列表不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            List<Item> books = bookTagService.searchBooksByTags(tagNames);
            logger.info("多标签搜索完成，找到 {} 本图书", books.size());

            List<Map<String, Object>> bookList = books.stream()
                .map(book -> {
                    Map<String, Object> bookMap = new HashMap<>();
                    bookMap.put("itemId", book.getItemId());
                    bookMap.put("itemName", book.getItemName());
                    bookMap.put("author", book.getAuthor());
                    bookMap.put("remainNumber", book.getRemainNumber());
                    bookMap.put("price", book.getPrice());
                    bookMap.put("coverUrl", book.getCoverUrl());
                    bookMap.put("isbn", book.getIsbn());
                    bookMap.put("publish", book.getPublish());
                    // 获取图书的标签
                    List<BookTag> tags = bookTagService.getBookTags(book.getItemId());
                    List<String> tagNamesList = tags.stream()
                            .map(BookTag::getTagName)
                            .collect(Collectors.toList());
                    bookMap.put("tags", tagNamesList);
                    return bookMap;
                })
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(bookList);
        } catch (Exception e) {
            logger.error("多标签搜索失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "多标签搜索失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 获取所有标签
     */
    @GetMapping("/tags")
    public ResponseEntity<?> getAllTags() {
        try {
            List<BookTag> tags = bookTagService.getAllTags();
            List<Map<String, Object>> tagList = tags.stream()
                .map(tag -> {
                    Map<String, Object> tagMap = new HashMap<>();
                    tagMap.put("tagId", tag.getTagId());
                    tagMap.put("tagName", tag.getTagName());
                    tagMap.put("description", tag.getDescription());
                    return tagMap;
                })
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(tagList);
        } catch (Exception e) {
            logger.error("获取标签列表失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "获取标签列表失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 获取图书的标签
     */
    @GetMapping("/books/{bookId}/tags")
    public ResponseEntity<?> getBookTags(@PathVariable String bookId) {
        try {
            List<BookTag> tags = bookTagService.getBookTags(bookId);
            List<Map<String, Object>> tagList = tags.stream()
                .map(tag -> {
                    Map<String, Object> tagMap = new HashMap<>();
                    tagMap.put("tagId", tag.getTagId());
                    tagMap.put("tagName", tag.getTagName());
                    tagMap.put("description", tag.getDescription());
                    return tagMap;
                })
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(tagList);
        } catch (Exception e) {
            logger.error("获取图书标签失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "获取图书标签失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 为图书添加标签
     */
    @PostMapping("/books/{bookId}/tags")
    public ResponseEntity<?> addTagToBook(@PathVariable String bookId, @RequestBody Map<String, Object> request) {
        try {
            logger.info("为图书 {} 添加标签，请求体: {}", bookId, request);
            
            Object tagObj = request.get("tagName");
            if (tagObj == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "标签名称不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            String tagName = tagObj.toString().trim();
            if (tagName.isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "标签名称不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            // 检查图书是否存在
            Item book = bookService.getBookById(bookId);
            if (book == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "图书不存在");
                return ResponseEntity.badRequest().body(error);
            }

            bookTagService.addTagToBook(bookId, tagName);
            
            // 同步到Neo4J
            try {
                neo4jTagService.createOrUpdateTag(tagName, null);
            } catch (Exception e) {
                logger.warn("同步标签到Neo4J失败: {}", e.getMessage());
            }

            Map<String, String> result = new HashMap<>();
            result.put("message", "标签添加成功");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("添加标签失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "添加标签失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 为图书批量添加标签
     */
    @PostMapping("/books/{bookId}/tags/batch")
    public ResponseEntity<?> addTagsToBook(@PathVariable String bookId, @RequestBody Map<String, Object> request) {
        try {
            logger.info("为图书 {} 批量添加标签，请求体: {}", bookId, request);
            
            @SuppressWarnings("unchecked")
            List<String> tagNames = (List<String>) request.get("tagNames");
            if (tagNames == null || tagNames.isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "标签名称列表不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            // 检查图书是否存在
            Item book = bookService.getBookById(bookId);
            if (book == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "图书不存在");
                return ResponseEntity.badRequest().body(error);
            }

            bookTagService.addTagsToBook(bookId, tagNames);
            
            // 同步到Neo4J
            try {
                for (String tagName : tagNames) {
                    neo4jTagService.createOrUpdateTag(tagName, null);
                }
            } catch (Exception e) {
                logger.warn("同步标签到Neo4J失败: {}", e.getMessage());
            }

            Map<String, String> result = new HashMap<>();
            result.put("message", "标签添加成功，共添加 " + tagNames.size() + " 个标签");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("批量添加标签失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "批量添加标签失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 从图书移除标签
     */
    @DeleteMapping("/books/{bookId}/tags/{tagName}")
    public ResponseEntity<?> removeTagFromBook(@PathVariable String bookId, @PathVariable String tagName) {
        try {
            logger.info("从图书 {} 移除标签 {}", bookId, tagName);
            
            bookTagService.removeTagFromBook(bookId, tagName);
            
            Map<String, String> result = new HashMap<>();
            result.put("message", "标签移除成功");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("移除标签失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "移除标签失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    /**
     * 更新图书的标签（替换所有标签）
     */
    @PutMapping("/books/{bookId}/tags")
    public ResponseEntity<?> updateBookTags(@PathVariable String bookId, @RequestBody Map<String, Object> request) {
        try {
            logger.info("更新图书 {} 的标签，请求体: {}", bookId, request);
            
            @SuppressWarnings("unchecked")
            List<String> tagNames = (List<String>) request.get("tagNames");
            if (tagNames == null) {
                tagNames = new ArrayList<>();
            }

            // 检查图书是否存在
            Item book = bookService.getBookById(bookId);
            if (book == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "图书不存在");
                return ResponseEntity.badRequest().body(error);
            }

            // 获取当前标签
            List<BookTag> currentTags = bookTagService.getBookTags(bookId);
            Set<String> currentTagNames = currentTags.stream()
                    .map(BookTag::getTagName)
                    .collect(Collectors.toSet());
            Set<String> newTagNames = new HashSet<>(tagNames);

            // 找出需要添加和删除的标签
            Set<String> toAdd = new HashSet<>(newTagNames);
            toAdd.removeAll(currentTagNames);
            
            Set<String> toRemove = new HashSet<>(currentTagNames);
            toRemove.removeAll(newTagNames);

            // 执行添加和删除
            for (String tagName : toAdd) {
                bookTagService.addTagToBook(bookId, tagName);
                try {
                    neo4jTagService.createOrUpdateTag(tagName, null);
                } catch (Exception e) {
                    logger.warn("同步标签到Neo4J失败: {}", e.getMessage());
                }
            }
            
            for (String tagName : toRemove) {
                bookTagService.removeTagFromBook(bookId, tagName);
            }

            Map<String, String> result = new HashMap<>();
            result.put("message", "标签更新成功");
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            logger.error("更新标签失败", e);
            Map<String, String> error = new HashMap<>();
            error.put("message", "更新标签失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 