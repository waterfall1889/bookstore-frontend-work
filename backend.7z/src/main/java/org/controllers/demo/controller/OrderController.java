package org.controllers.demo.controller;

import org.controllers.demo.entity.OrderMeta;
import org.controllers.demo.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private org.controllers.demo.service.remote.OrderPricingClient orderPricingClient;

    @PostMapping("/carts/user/{userId}/checkout")
    public ResponseEntity<?> checkout(@PathVariable String userId, @RequestBody Map<String, Object> request) {
        try {
            // 验证请求体中的userId是否与路径参数一致
            String requestUserId = (String) request.get("userId");
            if (!userId.equals(requestUserId)) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "用户ID不匹配");
                return ResponseEntity.badRequest().body(error);
            }

            OrderMeta order = orderService.createOrder(userId);
            
            // 构建响应
            Map<String, Object> response = new HashMap<>();
            response.put("orderId", order.getOrderId());
            response.put("status", order.getStatus());
            response.put("date", order.getDate());
            response.put("message", "订单创建成功");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/orders/user/{userId}")
    public ResponseEntity<?> getUserOrders(@PathVariable String userId) {
        try {
            List<OrderMeta> orders = orderService.getUserOrders(userId);
            if (orders == null || orders.isEmpty()) {
                return ResponseEntity.ok(new ArrayList<>()); // 返回空列表而不是错误
            }

            List<Map<String, Object>> orderList = orders.stream()
                .map(this::convertOrderToMap)
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(orderList);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "加载订单失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/orders/{orderId}")
    public ResponseEntity<?> getOrder(@PathVariable String orderId) {
        try {
            OrderMeta order = orderService.getOrderById(orderId);
            if (order == null) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "订单不存在");
                return ResponseEntity.badRequest().body(error);
            }

            return ResponseEntity.ok(convertOrderToMap(order));
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "加载订单失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PutMapping("/orders/{orderId}/status")
    public ResponseEntity<?> updateOrderStatus(@PathVariable String orderId,
                                             @RequestBody Map<String, String> request) {
        try {
            String status = request.get("status");
            if (status == null || !isValidStatus(status)) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "无效的订单状态");
                return ResponseEntity.badRequest().body(error);
            }

            orderService.updateOrderStatus(orderId, status);
            Map<String, String> response = new HashMap<>();
            response.put("message", "订单状态更新成功");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    private boolean isValidStatus(String status) {
        return status != null && (status.equals("WFP") || status.equals("IDL") || status.equals("FIN"));
    }

    @PostMapping("/orders/search")
    public ResponseEntity<?> searchOrders(@RequestBody Map<String, String> params) {
        try {
            String userId = params.get("userId");
            String startDate = params.get("startDate");
            String endDate = params.get("endDate");
            String bookName = params.get("bookName");

            List<OrderMeta> orders = orderService.searchOrders(userId, startDate, endDate, bookName);
            
            // 构建响应数据
            List<Map<String, Object>> orderList = orders.stream()
                .map(this::convertOrderToMap)
                .collect(Collectors.toList());
            
            return ResponseEntity.ok(orderList);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }


    @GetMapping("/orders/all")
    public ResponseEntity<?> getAllOrders() {
        try {
            List<OrderMeta> orders = orderService.getAllOrders();
            if (orders == null || orders.isEmpty()) {
                return ResponseEntity.ok(new ArrayList<>()); // 返回空列表而不是错误
            }

            List<Map<String, Object>> orderList = orders.stream()
                    .map(this::convertOrderToMap)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(orderList);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "加载订单失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }


    @PostMapping("/orders/searchAll")
    public ResponseEntity<?> searchAllOrders(@RequestBody Map<String, String> params) {
        try {
            String startDate = params.get("startDate");
            String endDate = params.get("endDate");
            String bookName = params.get("bookName");

            List<OrderMeta> orders = orderService.searchAllOrders(startDate, endDate, bookName);

            // 构建响应数据
            List<Map<String, Object>> orderList = orders.stream()
                    .map(this::convertOrderToMap)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(orderList);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    private Map<String, Object> convertOrderToMap(OrderMeta order) {
        Map<String, Object> orderMap = new HashMap<>();
        orderMap.put("orderId", order.getOrderId());
        orderMap.put("userId", order.getUserId());
        orderMap.put("status", order.getStatus());
        orderMap.put("date", order.getDate());

        List<Map<String, Object>> items = order.getOrderItems() != null
                ? order.getOrderItems().stream().map(item -> {
                    Map<String, Object> itemMap = new HashMap<>();
                    itemMap.put("itemId", item.getItemId());
                    itemMap.put("counts", item.getCounts());
                    if (item.getItem() != null) {
                        itemMap.put("itemName", item.getItem().getItemName());
                        itemMap.put("author", item.getItem().getAuthor());
                        itemMap.put("price", item.getItem().getPrice());
                        itemMap.put("coverUrl", item.getItem().getCoverUrl());
                        itemMap.put("remainNumber", item.getItem().getRemainNumber());
                    }

                    if (item.getItem() != null && item.getItem().getPrice() != null && item.getCounts() != null) {
                        var lineTotal = orderPricingClient.calculateLineTotal(
                                item.getItem().getPrice(), item.getCounts());
                        itemMap.put("lineTotal", lineTotal);
                    } else {
                        itemMap.put("lineTotal", java.math.BigDecimal.ZERO);
                    }
                    return itemMap;
                }).collect(Collectors.toList())
                : new ArrayList<>();

        orderMap.put("items", items);

        java.math.BigDecimal orderTotal = items.stream()
                .map(map -> (java.math.BigDecimal) map.getOrDefault("lineTotal", java.math.BigDecimal.ZERO))
                .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add);
        orderMap.put("orderTotal", orderTotal);

        return orderMap;
    }
} 