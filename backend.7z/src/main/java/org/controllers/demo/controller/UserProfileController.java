package org.controllers.demo.controller;

import org.controllers.demo.entity.UserProfile;
import org.controllers.demo.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class UserProfileController {
    private static final Logger logger = LoggerFactory.getLogger(UserProfileController.class);

    @Autowired
    private UserProfileService userProfileService;

    @PostMapping("/profile")
    public ResponseEntity<?> getUserProfile(@RequestBody Map<String, String> request) {
        try {
            String userId = request.get("id");
            if (userId == null || userId.trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "用户ID不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            UserProfile profile = userProfileService.getUserProfile(userId);
            if (profile == null) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "用户不存在");
                return ResponseEntity.badRequest().body(error);
            }

            // 构建符合前端期望的响应格式
            Map<String, String> response = new HashMap<>();
            response.put("user_name", profile.getUserMeta().getUsername());
            response.put("id", profile.getId());
            response.put("email", profile.getEmail());
            response.put("status", profile.getStatus());
            response.put("sign_date", profile.getRegisterDate());
            response.put("phone_number", profile.getPhone());
            response.put("description", profile.getDescription());
            response.put("avatar_url", profile.getAvatarUrl());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/profileInitial/{userId}")
    public ResponseEntity<?> getInitialProfile(@PathVariable String userId) {
        try {
            UserProfile profile = userProfileService.getUserProfile(userId);
            if (profile == null) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "用户不存在");
                return ResponseEntity.badRequest().body(error);
            }

            // 构建初始个人信息响应
            Map<String, String> response = new HashMap<>();
            response.put("user_name", profile.getUserMeta().getUsername());
            response.put("id", profile.getId());
            response.put("email", profile.getEmail());
            response.put("status", profile.getStatus());
            response.put("sign_date", profile.getRegisterDate());
            response.put("phone_number", profile.getPhone());
            response.put("description", profile.getDescription());
            response.put("avatar_url", profile.getAvatarUrl());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/UpdateProfile/{userId}")
    public ResponseEntity<?> updateUserProfile(@PathVariable String userId,
                                             @RequestBody Map<String, String> profileData) {
        try {
            logger.info("收到更新用户资料请求 - 用户ID: {}, 数据: {}", userId, profileData);

            if (profileData == null) {
                logger.error("请求体为空");
                Map<String, String> error = new HashMap<>();
                error.put("error", "请求体不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            // 验证必填字段
            if (profileData.get("user_email") == null || profileData.get("user_email").trim().isEmpty()) {
                logger.error("邮箱为空");
                Map<String, String> error = new HashMap<>();
                error.put("error", "邮箱不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            // 转换字段名称以匹配实体类
            Map<String, String> updates = new HashMap<>();
            updates.put("email", profileData.get("user_email"));
            updates.put("phone", profileData.get("phone_number")); // 如果前端没有发送，这里会是null
            updates.put("description", profileData.get("description"));
            updates.put("avatarUrl", profileData.get("avatar_url"));

            logger.info("准备更新用户资料 - 用户ID: {}, 更新数据: {}", userId, updates);

            UserProfile updatedProfile = userProfileService.updateUserProfile(userId, updates);
            
            if (updatedProfile == null) {
                logger.error("用户不存在 - 用户ID: {}", userId);
                Map<String, String> error = new HashMap<>();
                error.put("error", "用户不存在");
                return ResponseEntity.badRequest().body(error);
            }

            // 构建响应
            Map<String, String> response = new HashMap<>();
            response.put("user_name", updatedProfile.getUserMeta().getUsername());
            response.put("id", updatedProfile.getId());
            response.put("email", updatedProfile.getEmail());
            response.put("status", updatedProfile.getStatus());
            response.put("sign_date", updatedProfile.getRegisterDate());
            response.put("phone_number", updatedProfile.getPhone());
            response.put("description", updatedProfile.getDescription());
            response.put("avatar_url", updatedProfile.getAvatarUrl());

            logger.info("用户资料更新成功 - 用户ID: {}", userId);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("更新用户资料时发生错误 - 用户ID: {}, 错误: {}", userId, e.getMessage(), e);
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PutMapping("/profile/{userId}/avatar")
    public ResponseEntity<?> updateAvatar(@PathVariable String userId,
                                        @RequestBody Map<String, String> request) {
        try {
            String avatarUrl = request.get("avatarUrl");
            if (avatarUrl == null || avatarUrl.trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "头像URL不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            boolean success = userProfileService.updateAvatar(userId, avatarUrl);
            if (success) {
                Map<String, String> response = new HashMap<>();
                response.put("message", "头像更新成功");
                return ResponseEntity.ok(response);
            } else {
                Map<String, String> error = new HashMap<>();
                error.put("error", "头像更新失败");
                return ResponseEntity.badRequest().body(error);
            }
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 