package org.controllers.demo.controller;

import org.controllers.demo.entity.CartItem;
import org.controllers.demo.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping("/cart/{userId}")
    public ResponseEntity<?> getCartItems(@PathVariable String userId) {
        try {
            List<CartItem> cartItems = cartService.getCartItems(userId);
            return ResponseEntity.ok(cartItems);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/cart/add/{userId}")
    public ResponseEntity<?> addToCart(@PathVariable String userId,
                                     @RequestBody Map<String, Object> request) {
        try {
            String itemId = (String) request.get("itemId");
            Integer quantity = ((Number) request.get("quantity")).intValue();
            
            if (itemId == null || itemId.trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "商品ID不能为空");
                return ResponseEntity.badRequest().body(error);
            }
            
            if (quantity == null || quantity <= 0) {
                Map<String, String> error = new HashMap<>();
                error.put("error", "商品数量必须大于0");
                return ResponseEntity.badRequest().body(error);
            }
            
            CartItem cartItem = cartService.addToCart(userId, itemId, quantity);
            return ResponseEntity.ok(cartItem);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateCartItemCount(@RequestParam String userId,
                                               @RequestParam String itemId,
                                               @RequestParam Integer counts) {
        try {
            CartItem cartItem = cartService.updateCartItemCount(userId, itemId, counts);
            return ResponseEntity.ok(cartItem);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @PostMapping("/remove")
    public ResponseEntity<?> removeFromCart(@RequestBody Map<String, String> request) {
        try {
            String userId = request.get("userId");
            String itemId = request.get("itemId");
            cartService.removeFromCart(userId, itemId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "商品已成功从购物车中移除");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @DeleteMapping("/clear/{userId}")
    public ResponseEntity<?> clearCart(@PathVariable String userId) {
        try {
            cartService.clearCart(userId);
            Map<String, String> response = new HashMap<>();
            response.put("message", "购物车已清空");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
} 