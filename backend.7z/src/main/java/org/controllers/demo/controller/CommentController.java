package org.controllers.demo.controller;

import org.controllers.demo.entity.Comment;
import org.controllers.demo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/comments")
@CrossOrigin(origins = "*")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @GetMapping("/test/{itemId}")
    public ResponseEntity<?> testCommentLoading(@PathVariable String itemId) {
        try {
            List<Comment> comments = commentService.getCommentsByItemId(itemId);
            for (Comment comment : comments) {
                System.out.println("Comment ID: " + comment.getCommentId());
                System.out.println("Username: " + (comment.getUserMeta() != null ? comment.getUserMeta().getUsername() : "null"));
                System.out.println("Avatar URL: " + (comment.getUserProfile() != null ? comment.getUserProfile().getAvatarUrl() : "null"));
            }
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping
    public ResponseEntity<?> createComment(@RequestBody Comment comment) {
        try {
            Comment savedComment = commentService.createComment(comment);
            return ResponseEntity.ok(savedComment);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PutMapping("/{commentId}")
    public ResponseEntity<?> updateComment(@PathVariable String commentId, @RequestBody Comment comment) {
        try {
            Comment updatedComment = commentService.updateComment(commentId, comment);
            return ResponseEntity.ok(updatedComment);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{commentId}")
    public ResponseEntity<?> deleteComment(@PathVariable String commentId) {
        try {
            commentService.deleteComment(commentId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/{commentId}")
    public ResponseEntity<?> getCommentById(@PathVariable String commentId) {
        try {
            Comment comment = commentService.getCommentById(commentId);
            return ResponseEntity.ok(comment);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/item/{itemId}")
    public ResponseEntity<?> getCommentsByItemId(@PathVariable String itemId) {
        try {
            List<Comment> comments = commentService.getCommentsByItemId(itemId);
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/user/{commenterId}")
    public ResponseEntity<?> getCommentsByCommenterId(@PathVariable String commenterId) {
        try {
            List<Comment> comments = commentService.getCommentsByCommenterId(commenterId);
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/item/{itemId}/rating")
    public ResponseEntity<?> getAverageRatingByItemId(@PathVariable String itemId) {
        try {
            Double averageRating = commentService.getAverageRatingByItemId(itemId);
            return ResponseEntity.ok(averageRating);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/item/{itemId}/sorted")
    public ResponseEntity<?> getCommentsByItemIdOrderByTimeDesc(@PathVariable String itemId) {
        try {
            List<Comment> comments = commentService.getCommentsByItemIdOrderByTimeDesc(itemId);
            return ResponseEntity.ok(comments);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
} 