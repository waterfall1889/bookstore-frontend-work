package org.controllers.demo.controller;

import org.controllers.demo.entity.UserMeta;
import org.controllers.demo.entity.UserProfile;
import org.controllers.demo.service.UserService;
import org.controllers.demo.service.SessionTimerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
@Scope("singleton")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private SessionTimerService sessionTimerService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody(required = false) Map<String, Object> loginData) {
        logger.info("收到登录请求 - 原始请求数据: {}", loginData);

        try {
            // 验证请求数据
            if (loginData == null) {
                logger.error("登录失败 - 请求数据为空");
                return ResponseEntity.status(400).body(Map.of("message", "请求数据不能为空"));
            }

            // 提取并转换用户名和密码
            String username = null;
            String password = null;

            // 处理嵌套的数据结构
            Object usernameObj = loginData.get("username");
            if (usernameObj instanceof Map) {
                Map<String, Object> usernameMap = (Map<String, Object>) usernameObj;
                username = String.valueOf(usernameMap.get("username"));
                password = String.valueOf(usernameMap.get("password"));
                logger.info("从嵌套结构中提取数据 - 用户名: {}, 密码长度: {}", username, password.length());
            } else {
                username = String.valueOf(usernameObj);
                password = String.valueOf(loginData.get("password"));
                logger.info("从扁平结构中提取数据 - 用户名: {}, 密码长度: {}", username, password.length());
            }

            // 验证必填字段
            if (username == null || username.trim().isEmpty() || "null".equals(username)) {
                logger.warn("登录失败 - 用户名为空");
                return ResponseEntity.status(400).body(Map.of("message", "用户名不能为空"));
            }
            if (password == null || password.trim().isEmpty() || "null".equals(password)) {
                logger.warn("登录失败 - 密码为空");
                return ResponseEntity.status(400).body(Map.of("message", "密码不能为空"));
            }

            // 执行登录
            UserMeta userMeta = userService.login(username, password);

            // 获取用户档案信息
            UserProfile userProfile = userService.getUserProfile(userMeta.getId());
            if (userProfile == null) {
                logger.error("登录失败 - 用户档案不存在 - 用户ID: {}", userMeta.getId());
                return ResponseEntity.status(400).body(Map.of("message", "用户档案不存在"));
            }

            // 开始会话计时
            sessionTimerService.startTimer(userMeta.getId());
            logger.info("开始会话计时 - 用户ID: {}", userMeta.getId());

            // 构建响应
            Map<String, Object> response = new HashMap<>();
            response.put("id", userMeta.getId());
            response.put("username", userMeta.getUsername());
            response.put("status", userProfile.getStatus());  // 添加用户身份信息
            response.put("message", "登录成功");
            response.put("loginStatus", "success");

            logger.info("登录成功 - 用户ID: {}, 用户名: {}, 身份: {}",
                    userMeta.getId(),
                    userMeta.getUsername(),
                    userProfile.getStatus());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("登录失败 - 异常信息: {}", e.getMessage(), e);
            String msg = e.getMessage();
            String code = "LOGIN_ERROR";
            if (msg != null) {
                if (msg.contains("禁用")) {
                    code = "USER_DISABLED";
                } else if (msg.contains("用户名或密码错误")) {
                    code = "CREDENTIALS_ERROR";
                } else if (msg.contains("认证信息不存在")) {
                    code = "AUTH_NOT_FOUND";
                }
            }
            return ResponseEntity.status(400).body(Map.of(
                    "message", msg,
                    "code", code
            ));
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestBody Map<String, String> request) {
        try {
            String userId = request.get("userId");
            if (userId == null || userId.trim().isEmpty()) {
                logger.warn("登出失败 - 用户ID为空");
                return ResponseEntity.status(400).body(Map.of("message", "用户ID不能为空"));
            }

            // 停止会话计时并获取会话时长
            long sessionDuration = sessionTimerService.stopTimer(userId);

            // 计算会话时长（分钟和秒）
            long minutes = sessionDuration / 60000;
            long seconds = (sessionDuration % 60000) / 1000;

            logger.info("用户登出 - 用户ID: {}, 会话时长: {} 分钟 {} 秒", userId, minutes, seconds);

            // 构建响应
            Map<String, Object> response = new HashMap<>();
            response.put("message", "登出成功");
            response.put("sessionDuration", sessionDuration);
            response.put("sessionMinutes", minutes);
            response.put("sessionSeconds", seconds);
            response.put("sessionTimeFormatted", String.format("%d分%d秒", minutes, seconds));

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("登出失败 - 异常信息: {}", e.getMessage(), e);
            return ResponseEntity.status(400).body(Map.of(
                    "message", "登出失败: " + e.getMessage()
            ));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody Map<String, String> userData) {
        try {
            // 验证必填字段
            if (userData.get("username") == null || userData.get("username").trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "用户名不能为空");
                return ResponseEntity.badRequest().body(error);
            }
            if (userData.get("password") == null || userData.get("password").trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "密码不能为空");
                return ResponseEntity.badRequest().body(error);
            }
            if (userData.get("email") == null || userData.get("email").trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "邮箱不能为空");
                return ResponseEntity.badRequest().body(error);
            }
            if (userData.get("phone") == null || userData.get("phone").trim().isEmpty()) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "手机号不能为空");
                return ResponseEntity.badRequest().body(error);
            }

            // 检查用户名是否已存在
            if (userService.isUsernameExists(userData.get("username"))) {
                Map<String, String> error = new HashMap<>();
                error.put("message", "用户名已存在");
                return ResponseEntity.badRequest().body(error);
            }

            // 创建用户
            UserProfile user = userService.registerUser(
                    userData.get("username"),
                    userData.get("password"),
                    userData.get("email"),
                    userData.get("phone"),
                    userData.get("description")
            );

            // 构建响应
            Map<String, Object> response = new HashMap<>();
            response.put("id", user.getId());
            response.put("username", user.getUserMeta().getUsername());
            response.put("email", user.getEmail());
            response.put("phone", user.getPhone());
            response.put("description", user.getDescription());
            response.put("message", "注册成功");

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", "注册失败: " + e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }

    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers() {
        try {
            logger.info("获取用户列表请求");
            List<UserProfile> users = userService.getAllUsers();

            // 转换为前端需要的格式
            List<Map<String, Object>> userList = users.stream()
                    .map(user -> {
                        Map<String, Object> userMap = new HashMap<>();
                        userMap.put("id", user.getId());
                        userMap.put("username", user.getUserMeta().getUsername());
                        userMap.put("avatar", user.getAvatarUrl());
                        // 使用UserAuth中的validness作为状态
                        boolean validness = user.getUserAuth() != null && user.getUserAuth().getValidness();
                        userMap.put("status", validness ? 1 : 0);
                        userMap.put("role", user.getStatus()); // 保持角色信息不变
                        return userMap;
                    })
                    .collect(Collectors.toList());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", userList);

            logger.info("成功获取用户列表 - 共 {} 个用户", userList.size());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("获取用户列表失败: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", "获取用户列表失败: " + e.getMessage()
            ));
        }
    }

    @PutMapping("/users/{userId}/status")
    public ResponseEntity<?> updateUserStatus(
            @PathVariable String userId,
            @RequestBody Map<String, String> request) {
        try {
            logger.info("更新用户状态请求 - 用户ID: {}, 请求数据: {}", userId, request);

            String status = request.get("status");
            if (status == null || status.trim().isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "状态不能为空"
                ));
            }

            // 验证状态值
            if (!"0".equals(status) && !"1".equals(status)) {
                return ResponseEntity.badRequest().body(Map.of(
                        "success", false,
                        "message", "无效的状态值，只能是0或1"
                ));
            }

            UserProfile updatedUser = userService.updateUserStatus(userId, status);

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "更新成功");
            response.put("data", Map.of(
                    "id", updatedUser.getId(),
                    "status", updatedUser.getStatus() // 直接返回字符串
            ));

            logger.info("用户状态更新成功 - 用户ID: {}, 新状态: {}", userId, status);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("更新用户状态失败: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }
} 