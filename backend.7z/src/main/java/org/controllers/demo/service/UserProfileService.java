package org.controllers.demo.service;

import org.controllers.demo.entity.UserProfile;
import java.util.Map;
 
public interface UserProfileService {
    UserProfile getUserProfile(String userId);
    UserProfile updateUserProfile(String userId, Map<String, String> updates);
    boolean updateAvatar(String userId, String avatarUrl);
} 