package org.controllers.demo.service;

/**
 * 会话计时器服务接口
 * 用于记录用户登录后的会话保持时间
 */
public interface SessionTimerService {
    
    /**
     * 开始计时
     * @param userId 用户ID
     */
    void startTimer(String userId);
    
    /**
     * 停止计时并获取会话时长
     * @param userId 用户ID
     * @return 会话时长（毫秒）
     */
    long stopTimer(String userId);
    
    /**
     * 获取当前会话时长
     * @param userId 用户ID
     * @return 当前会话时长（毫秒），如果未开始计时返回0
     */
    long getCurrentSessionTime(String userId);
    
    /**
     * 清理过期的计时器
     */
    void cleanupExpiredTimers();
}