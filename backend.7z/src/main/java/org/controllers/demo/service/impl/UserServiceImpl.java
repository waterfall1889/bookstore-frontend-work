package org.controllers.demo.service.impl;

import org.controllers.demo.entity.UserAuth;
import org.controllers.demo.entity.UserMeta;
import org.controllers.demo.entity.UserProfile;
import org.controllers.demo.dao.UserMetaDao;
import org.controllers.demo.dao.UserAuthDao;
import org.controllers.demo.dao.UserProfileDao;
import org.controllers.demo.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    private static final String DEFAULT_AVATAR_URL = "http://localhost:8080/images/default.png";

    @Autowired
    private UserMetaDao userMetaDao;

    @Autowired
    private UserAuthDao userAuthDao;

    @Autowired
    private UserProfileDao userProfileDao;

    @Override
    @Transactional
    public UserMeta register(String username, String password) {
        logger.info("开始注册用户: {}", username);

        // 检查用户名是否已存在
        if (isUsernameExists(username)) {
            logger.warn("用户名已存在: {}", username);
            throw new RuntimeException("用户名已存在");
        }

        // 生成用户ID
        String userId = generateUserId();
        logger.info("生成用户ID: {}", userId);

        // 创建用户元数据
        UserMeta userMeta = new UserMeta();
        userMeta.setId(userId);
        userMeta.setUsername(username);
        userMetaDao.save(userMeta);
        logger.info("保存用户元数据成功");

        // 生成salt和hashValue
        String salt = generateSalt();
        logger.info("生成16位随机salt: {}", salt);
        String hashValue = generateHashValue(password, salt);
        logger.info("生成64位hashValue: {}", hashValue);

        // 创建用户认证信息
        UserAuth userAuth = new UserAuth();
        userAuth.setId(userId);
        userAuth.setSalt(salt);
        userAuth.setHashValue(hashValue);
        userAuth.setValidness(true);
        userAuthDao.save(userAuth);
        logger.info("保存用户认证信息成功");

        // 创建用户档案
        UserProfile userProfile = new UserProfile();
        userProfile.setId(userId);
        userProfile.setAvatarUrl(DEFAULT_AVATAR_URL);
        userProfileDao.save(userProfile);
        logger.info("保存用户档案成功");

        return userMeta;
    }

    @Override
    public UserMeta login(String username, String password) {
        logger.info("开始登录流程 - 用户名: {}", username);

        // 查找用户
        UserMeta userMeta = userMetaDao.findByUsername(username);
        if (userMeta == null) {
            logger.warn("登录失败 - 用户不存在: {}", username);
            throw new RuntimeException("用户名或密码错误");
        }
        logger.info("找到用户信息 - 用户ID: {}", userMeta.getId());

        // 获取用户认证信息
        UserAuth userAuth = userAuthDao.findById(userMeta.getId());
        if (userAuth == null) {
            logger.error("登录失败 - 用户认证信息不存在 - 用户ID: {}", userMeta.getId());
            throw new RuntimeException("用户认证信息不存在");
        }
        logger.info("获取到用户认证信息 - 用户ID: {}", userAuth.getId());

        // 检查用户是否有效
        if (!userAuth.getValidness()) {
            logger.warn("登录失败 - 用户已被禁用 - 用户ID: {}", userAuth.getId());
            throw new RuntimeException("账号已被禁用");
        }
        logger.info("用户状态检查通过 - 账号有效");

        // 验证密码
        String inputHashValue = generateHashValue(password, userAuth.getSalt());
        logger.info("密码验证 - 用户ID: {}", userAuth.getId());
        logger.info("密码验证 - 使用的salt: {}", userAuth.getSalt());
        logger.info("密码验证 - 存储的hashValue: {}", userAuth.getHashValue());
        logger.info("密码验证 - 计算的hashValue: {}", inputHashValue);

        if (!inputHashValue.equals(userAuth.getHashValue())) {
            logger.warn("登录失败 - 密码错误 - 用户ID: {}", userAuth.getId());
            throw new RuntimeException("用户名或密码错误");
        }
        logger.info("密码验证通过");

        logger.info("登录成功 - 用户ID: {}, 用户名: {}", userMeta.getId(), username);
        return userMeta;
    }

    @Override
    public boolean isUsernameExists(String username) {
        try {
            return userMetaDao.findByUsername(username) != null;
        } catch (Exception e) {
            logger.error("检查用户名是否存在时发生错误: {}", e.getMessage());
            return false;
        }
    }

    @Override
    @Transactional
    public UserProfile registerUser(String username, String password, String email, String phone, String description) {
        logger.info("开始注册用户: {}", username);
        
        // 生成8位随机ID
        String userId = generateUserId();
        logger.info("生成用户ID: {}", userId);
        
        // 创建并保存用户元数据
        UserMeta userMeta = new UserMeta();
        userMeta.setId(userId);
        userMeta.setUsername(username);
        userMetaDao.save(userMeta);
        logger.info("保存用户元数据成功");

        // 生成salt和hashValue
        String salt = generateSalt();
        logger.info("生成16位随机salt: {}", salt);
        String hashValue = generateHashValue(password, salt);
        logger.info("生成64位hashValue: {}", hashValue);

        // 创建并保存用户认证信息
        UserAuth userAuth = new UserAuth();
        userAuth.setId(userId);
        userAuth.setSalt(salt);
        userAuth.setHashValue(hashValue);
        userAuth.setValidness(true);
        userAuthDao.save(userAuth);
        logger.info("保存用户认证信息成功");

        // 创建用户档案
        UserProfile userProfile = new UserProfile();
        userProfile.setId(userId);
        userProfile.setEmail(email);
        userProfile.setPhone(phone);
        userProfile.setDescription(description != null ? description : "");
        userProfile.setStatus("BASIC");
        userProfile.setRegisterDate(LocalDate.now().format(DateTimeFormatter.ISO_DATE));
        userProfile.setAvatarUrl(DEFAULT_AVATAR_URL);

        // 设置关联
        userProfile.setUserMeta(userMeta);
        userProfile.setUserAuth(userAuth);

        // 保存用户档案
        userProfileDao.save(userProfile);
        logger.info("保存用户档案成功");

        return userProfile;
    }

    @Override
    public UserProfile getUserProfile(String userId) {
        logger.info("获取用户档案 - 用户ID: {}", userId);
        return userProfileDao.findById(userId);
    }

    @Override
    public List<UserProfile> getAllUsers() {
        logger.info("获取所有用户列表");
        List<UserProfile> users = userProfileDao.findAll();
        logger.info("找到 {} 个用户", users.size());
        return users;
    }

    @Override
    @Transactional
    public UserProfile updateUserStatus(String userId, String status) {
        logger.info("更新用户状态 - 用户ID: {}, 新状态: {}", userId, status);
        
        // 验证状态值
        if (!"0".equals(status) && !"1".equals(status)) {
            logger.error("无效的状态值: {}", status);
            throw new RuntimeException("无效的状态值");
        }

        // 获取用户档案
        UserProfile userProfile = userProfileDao.findById(userId);
        if (userProfile == null) {
            logger.error("用户不存在 - 用户ID: {}", userId);
            throw new RuntimeException("用户不存在");
        }

        // 检查是否是管理员
        if ("SUPER".equals(userProfile.getStatus())) {
            logger.error("不能修改管理员状态 - 用户ID: {}", userId);
            throw new RuntimeException("不能修改管理员状态");
        }

        // 获取并更新用户认证信息
        UserAuth userAuth = userAuthDao.findById(userId);
        if (userAuth == null) {
            logger.error("用户认证信息不存在 - 用户ID: {}", userId);
            throw new RuntimeException("用户认证信息不存在");
        }

        // 更新validness状态
        userAuth.setValidness("1".equals(status));
        userAuthDao.save(userAuth);
        logger.info("用户状态更新成功 - 用户ID: {}, 新状态: {}", userId, status);

        return userProfile;
    }

    private String generateUserId() {
        return String.format("%08d", Math.abs(UUID.randomUUID().hashCode() % 100000000));
    }

    private String generateSalt() {
        // 生成12个随机字节，Base64编码后会得到16个字符
        byte[] salt = new byte[12];
        new Random().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt).substring(0, 16);
    }

    private String generateHashValue(String password, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            String combined = password + salt;
            byte[] hash = md.digest(combined.getBytes());
            // 使用48个字节生成64个字符的Base64编码
            byte[] extendedHash = new byte[48];
            System.arraycopy(hash, 0, extendedHash, 0, hash.length);
            // 填充剩余字节
            for (int i = hash.length; i < extendedHash.length; i++) {
                extendedHash[i] = (byte) (hash[i % hash.length] ^ extendedHash[i - hash.length]);
            }
            return Base64.getEncoder().encodeToString(extendedHash).substring(0, 64);
        } catch (NoSuchAlgorithmException e) {
            logger.error("生成哈希值失败", e);
            throw new RuntimeException("生成哈希值失败", e);
        }
    }
} 