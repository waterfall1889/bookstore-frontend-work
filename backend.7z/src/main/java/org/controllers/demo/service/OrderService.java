package org.controllers.demo.service;

import org.controllers.demo.entity.OrderMeta;
import java.util.List;

public interface OrderService {
    OrderMeta createOrder(String userId);
    List<OrderMeta> getUserOrders(String userId);
    OrderMeta getOrderById(String orderId);
    void updateOrderStatus(String orderId, String status);
    List<OrderMeta> searchOrders(String userId, String startDate, String endDate, String bookName);
    List<OrderMeta> searchAllOrders(String startDate, String endDate, String bookName);
    List<OrderMeta> getAllOrders();
} 