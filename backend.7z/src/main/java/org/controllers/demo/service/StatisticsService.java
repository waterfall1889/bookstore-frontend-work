package org.controllers.demo.service;

import java.util.Map;

public interface StatisticsService {
    Map<String, Object> getUserStatistics(String userId, String startDate, String endDate);

    Map<String, Object> getAllStatistics(String startDate, String endDate);
} 