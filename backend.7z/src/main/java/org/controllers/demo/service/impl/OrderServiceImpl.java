package org.controllers.demo.service.impl;

import org.controllers.demo.entity.CartItem;
import org.controllers.demo.entity.Item;
import org.controllers.demo.entity.OrderItem;
import org.controllers.demo.entity.OrderMeta;
import org.controllers.demo.repository.CartItemRepository;
import org.controllers.demo.repository.ItemRepository;
import org.controllers.demo.repository.OrderItemRepository;
import org.controllers.demo.repository.OrderMetaRepository;
import org.controllers.demo.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.controllers.demo.cache.BookCacheService;
import org.controllers.demo.dao.OrderDao;
import org.controllers.demo.dao.CartDao;
import org.controllers.demo.dao.ItemDao;
import org.controllers.demo.websocket.OrderWebSocketHandler;

@Service
public class OrderServiceImpl implements OrderService {
    private static final Logger logger = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private OrderDao orderDao;

    @Autowired
    private CartDao cartDao;

    @Autowired
    private ItemDao itemDao;
    
    @Autowired
    private BookCacheService bookCacheService;

    @Autowired
    private OrderWebSocketHandler webSocketHandler;

    @Override
    @Transactional
    public OrderMeta createOrder(String userId) {
        // 1. 获取用户购物车中的商品
        List<CartItem> cartItems = cartDao.findByUserId(userId);
        if (cartItems.isEmpty()) {
            throw new RuntimeException("购物车为空");
        }

        // 2. 生成订单ID
        String orderId = generateOrderId();

        // 3. 创建订单元数据
        OrderMeta orderMeta = new OrderMeta();
        orderMeta.setOrderId(orderId);
        orderMeta.setUserId(userId);
        orderMeta.setStatus("WFP"); // 待支付状态
        orderMeta.setDate(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        orderDao.saveOrderMeta(orderMeta);

        // 4. 创建订单项并更新库存
        for (CartItem cartItem : cartItems) {
            Item item = itemDao.findById(cartItem.getItemId());
            if (item == null) {
                throw new RuntimeException("商品不存在");
            }

            // 检查库存
            if (item.getRemainNumber() < cartItem.getCounts()) {
                throw new RuntimeException("商品库存不足: " + item.getItemName());
            }

            // 创建订单项
            OrderItem orderItem = new OrderItem();
            orderItem.setOrderId(orderId);
            orderItem.setItemId(cartItem.getItemId());
            orderItem.setCounts(cartItem.getCounts());
            orderDao.saveOrderItem(orderItem);

            // 更新库存
            logger.info("[OrderService] ========== 开始更新图书库存 ========== - itemId: {}, 订单: {}", 
                item.getItemId(), orderId);
            
            int oldStock = item.getRemainNumber();
            int newStock = oldStock - cartItem.getCounts();
            item.setRemainNumber(newStock);
            
            logger.info("[OrderService] 库存变更详情 - itemId: {}, 书名: {}, 旧库存: {}, 减少: {}, 新库存: {}", 
                item.getItemId(), item.getItemName(), oldStock, cartItem.getCounts(), newStock);
            
            // 保存到数据库（这会自动更新缓存，因为ItemDao.save会调用bookCacheService.setBook）
            logger.debug("[OrderService] 步骤1: 更新MySQL数据库中的库存");
            itemDao.save(item);
            logger.info("[OrderService] ✅ MySQL数据库库存更新成功 - itemId: {}, 新库存: {}", 
                item.getItemId(), newStock);
            
            // 同时直接更新缓存中的库存（原子操作）
            logger.debug("[OrderService] 步骤2: 原子更新Redis缓存中的库存");
            boolean cacheUpdated = bookCacheService.updateBookStock(item.getItemId(), -cartItem.getCounts());
            if (cacheUpdated) {
                logger.info("[OrderService] ✅ Redis缓存库存更新成功（原子操作） - itemId: {}", item.getItemId());
            } else {
                logger.warn("[OrderService] ⚠️ Redis缓存库存更新失败，但数据库已更新 - itemId: {}", item.getItemId());
            }
            logger.info("[OrderService] ========== 库存更新完成 ==========");
        }

        // 5. 清空购物车
        cartDao.deleteByUserId(userId);

        // 6. 通过WebSocket推送订单创建成功消息给用户
        try {
            logger.info("准备通过WebSocket推送订单结果 - 用户ID: {}, 订单ID: {}", userId, orderId);
            boolean sent = webSocketHandler.sendOrderResult(
                userId, 
                orderId, 
                "WFP", 
                "订单创建成功，等待支付"
            );
            if (sent) {
                logger.info("WebSocket推送成功 - 订单ID: {}", orderId);
            } else {
                logger.warn("WebSocket推送失败 - 用户可能未连接 - 订单ID: {}", orderId);
            }
        } catch (Exception e) {
            logger.error("WebSocket推送异常 - 订单ID: {}", orderId, e);
            // WebSocket推送失败不影响订单创建，所以不抛出异常
        }

        return orderMeta;
    }

    @Override
    public List<OrderMeta> getUserOrders(String userId) {
        return orderDao.findOrdersByUserId(userId);
    }

    @Override
    public OrderMeta getOrderById(String orderId) {
        return orderDao.findOrderById(orderId);
    }

    @Override
    @Transactional
    public void updateOrderStatus(String orderId, String status) {
        OrderMeta order = getOrderById(orderId);
        order.setStatus(status);
        orderDao.saveOrderMeta(order);
    }

    @Override
    public List<OrderMeta> searchOrders(String userId, String startDate, String endDate, String bookName) {
        logger.info("开始搜索订单 - 用户ID: {}, 开始日期: {}, 结束日期: {}, 书名: {}", 
            userId, startDate, endDate, bookName);

        // 如果userId为空，直接查所有订单（管理员情形）
        if (userId == null || userId.trim().isEmpty()) {
            return searchAllOrders(startDate, endDate, bookName);
        }

        List<OrderMeta> orders;
        
        // 如果提供了日期范围，则按日期范围查询
        if (startDate != null && endDate != null && !startDate.isEmpty() && !endDate.isEmpty()) {
            orders = orderDao.findOrdersByUserIdAndDateBetween(userId, startDate, endDate);
            logger.info("按日期范围查询到{}个订单", orders.size());
        } else {
            // 否则获取用户的所有订单
            orders = orderDao.findOrdersByUserId(userId);
            logger.info("查询到用户所有订单{}个", orders.size());
        }

        if (orders.isEmpty()) {
            return Collections.emptyList();
        }

        // 如果提供了书名，则过滤包含该书的订单
        if (bookName != null && !bookName.trim().isEmpty()) {
            Set<String> matchingOrderIds = new HashSet<>();
            
            for (OrderMeta order : orders) {
                List<OrderItem> items = orderDao.findOrderItemsByOrderId(order.getOrderId());
                logger.debug("订单[{}]包含{}个商品项", order.getOrderId(), items.size());
                
                // 检查订单中的商品是否包含搜索的书名
                boolean hasMatchingBook = items.stream()
                    .anyMatch(item -> {
                        Item book = item.getItem();
                        return book != null && 
                               book.getItemName() != null && 
                               book.getItemName().toLowerCase().contains(bookName.toLowerCase());
                    });
                
                if (hasMatchingBook) {
                    matchingOrderIds.add(order.getOrderId());
                    logger.info("订单[{}]包含匹配的书籍", order.getOrderId());
                }
            }
            
            // 只保留包含匹配书籍的订单
            orders = orders.stream()
                .filter(order -> matchingOrderIds.contains(order.getOrderId()))
                .collect(Collectors.toList());
            
            logger.info("找到{}个包含指定书籍的订单", orders.size());
        }

        // 加载每个订单的订单项
        for (OrderMeta order : orders) {
            List<OrderItem> items = orderDao.findOrderItemsByOrderId(order.getOrderId());
            order.setOrderItems(items);
        }

        return orders;
    }

    @Override
    public List<OrderMeta> searchAllOrders(String startDate, String endDate, String bookName) {
        logger.info("开始搜索订单 - 开始日期: {}, 结束日期: {}, 书名: {}",
                startDate, endDate, bookName);

        List<OrderMeta> orders;

        // 如果提供了日期范围，则按日期范围查询
        if (startDate != null && endDate != null && !startDate.isEmpty() && !endDate.isEmpty()) {
            orders = orderDao.findAllOrdersAndDateBetween(startDate, endDate);
            logger.info("按日期范围查询到{}个订单", orders.size());
        } else {
            // 否则获取所有订单
            orders = orderDao.findAllOrders();
            logger.info("查询到所有订单{}个", orders.size());
        }

        if (orders.isEmpty()) {
            return Collections.emptyList();
        }

        // 如果提供了书名，则过滤包含该书的订单
        if (bookName != null && !bookName.trim().isEmpty()) {
            Set<String> matchingOrderIds = new HashSet<>();

            for (OrderMeta order : orders) {
                List<OrderItem> items = orderDao.findOrderItemsByOrderId(order.getOrderId());
                logger.debug("订单[{}]包含{}个商品项", order.getOrderId(), items.size());

                // 检查订单中的商品是否包含搜索的书名
                boolean hasMatchingBook = items.stream()
                        .anyMatch(item -> {
                            Item book = item.getItem();
                            return book != null &&
                                    book.getItemName() != null &&
                                    book.getItemName().toLowerCase().contains(bookName.toLowerCase());
                        });

                if (hasMatchingBook) {
                    matchingOrderIds.add(order.getOrderId());
                    logger.info("订单[{}]包含匹配的书籍", order.getOrderId());
                }
            }

            // 只保留包含匹配书籍的订单
            orders = orders.stream()
                    .filter(order -> matchingOrderIds.contains(order.getOrderId()))
                    .collect(Collectors.toList());

            logger.info("找到{}个包含指定书籍的订单", orders.size());
        }

        // 加载每个订单的订单项
        for (OrderMeta order : orders) {
            List<OrderItem> items = orderDao.findOrderItemsByOrderId(order.getOrderId());
            order.setOrderItems(items);
        }

        return orders;
    }

    @Override
    public List<OrderMeta> getAllOrders() {
        List<OrderMeta> orders = orderDao.findAllOrders();

        if (orders == null || orders.isEmpty()) {
            return Collections.emptyList();
        }

        // 2. 为每个订单加载订单项
        for (OrderMeta order : orders) {
            List<OrderItem> items = orderDao.findOrderItemsByOrderId(order.getOrderId());
            order.setOrderItems(items);

            // 3. 为每个订单项加载商品详细信息
            for (OrderItem item : items) {
                Item product = itemDao.findById(item.getItemId());
                item.setItem(product);
            }
        }

        return orders;
    }

    private String generateOrderId() {
        // 生成10位订单号：时间戳后6位 + 4位随机数
        String timestamp = String.valueOf(System.currentTimeMillis());
        String random = String.format("%04d", (int)(Math.random() * 10000));
        return timestamp.substring(timestamp.length() - 6) + random;
    }
} 