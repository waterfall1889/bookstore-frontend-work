package org.controllers.demo.service;

import org.controllers.demo.entity.neo4j.TagNode;
import org.controllers.demo.repository.neo4j.TagNodeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.neo4j.core.Neo4jTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class Neo4jTagService {
    private static final Logger logger = LoggerFactory.getLogger(Neo4jTagService.class);

    @Autowired(required = false)
    private TagNodeRepository tagNodeRepository;

    @Autowired(required = false)
    private Neo4jTemplate neo4jTemplate;

    /**
     * 创建或更新标签节点
     */
    public TagNode createOrUpdateTag(String tagName, String description) {
        if (tagNodeRepository == null) {
            logger.warn("TagNodeRepository未注入，无法创建标签: {}", tagName);
            return null;
        }
        
        try {
            // 先清理可能存在的重复标签
            cleanupDuplicateTagByName(tagName);
            
            // 查找现有标签
            Optional<TagNode> existing = tagNodeRepository.findByName(tagName);
            
            if (existing.isPresent()) {
                TagNode tag = existing.get();
                if (description != null) {
                    tag.setDescription(description);
                }
                // 确保集合已初始化
                if (tag.getParentTags() == null) {
                    tag.setParentTags(new HashSet<>());
                }
                if (tag.getChildTags() == null) {
                    tag.setChildTags(new HashSet<>());
                }
                return tagNodeRepository.save(tag);
            } else {
                TagNode tag = new TagNode(tagName, description);
                return tagNodeRepository.save(tag);
            }
        } catch (Exception e) {
            logger.error("创建或更新标签失败: {}", tagName, e);
            // 如果保存失败，可能是由于重复，再次清理后重试
            try {
                cleanupDuplicateTagByName(tagName);
                Optional<TagNode> retryTag = tagNodeRepository.findByName(tagName);
                if (retryTag.isPresent()) {
                    return retryTag.get();
                }
            } catch (Exception retryException) {
                logger.error("重试创建标签失败: {}", tagName, retryException);
            }
            throw e;
        }
    }

    /**
     * 创建标签之间的父子关系（子标签 -> 父标签）
     * 例如：Science Fiction -> Fiction
     */
    public void createSubcategoryRelation(String childTagName, String parentTagName) {
        if (tagNodeRepository == null) {
            logger.warn("TagNodeRepository未注入，无法创建标签关系: {} -> {}", childTagName, parentTagName);
            return;
        }
        
        try {
            // 先清理可能存在的重复标签
            cleanupDuplicateTagByName(childTagName);
            cleanupDuplicateTagByName(parentTagName);
            
            // 获取或创建子标签
            TagNode child = tagNodeRepository.findByName(childTagName)
                    .orElseGet(() -> {
                        logger.info("创建子标签: {}", childTagName);
                        return createOrUpdateTag(childTagName, null);
                    });
            
            // 获取或创建父标签
            TagNode parent = tagNodeRepository.findByName(parentTagName)
                    .orElseGet(() -> {
                        logger.info("创建父标签: {}", parentTagName);
                        return createOrUpdateTag(parentTagName, null);
                    });

            // 重新加载以确保获取最新的节点（避免重复）
            child = tagNodeRepository.findByName(childTagName).orElse(child);
            parent = tagNodeRepository.findByName(parentTagName).orElse(parent);

            // 提取parent的名称到final变量，供lambda使用
            final String parentName = parent.getName();
            final TagNode finalParent = parent;

            // 检查关系是否已存在
            if (child.getParentTags() == null) {
                child.setParentTags(new HashSet<>());
            }
            
            // 检查是否已存在关系（通过比较name而不是对象引用）
            boolean relationExists = child.getParentTags().stream()
                    .anyMatch(p -> p.getName() != null && p.getName().equals(parentName));
            
            if (!relationExists) {
                child.getParentTags().add(finalParent);
                // 保存前再次确保没有重复
                cleanupDuplicateTagByName(childTagName);
                // 重新加载节点
                child = tagNodeRepository.findByName(childTagName).orElse(child);
                if (child.getParentTags() == null) {
                    child.setParentTags(new HashSet<>());
                }
                // 重新添加关系（如果还没有）
                boolean stillExists = child.getParentTags().stream()
                        .anyMatch(p -> p.getName() != null && p.getName().equals(parentName));
                if (!stillExists) {
                    child.getParentTags().add(finalParent);
                }
                // 保存
                tagNodeRepository.save(child);
                logger.info("创建标签关系: {} -> {}", childTagName, parentTagName);
            } else {
                logger.debug("标签关系已存在: {} -> {}", childTagName, parentTagName);
            }
        } catch (Exception e) {
            logger.error("创建标签关系失败: {} -> {}", childTagName, parentTagName, e);
            // 如果保存失败，尝试清理后重试一次
            try {
                cleanupDuplicateTagByName(childTagName);
                cleanupDuplicateTagByName(parentTagName);
                logger.info("清理重复标签后，关系创建可能已成功");
            } catch (Exception retryException) {
                logger.error("重试清理失败", retryException);
            }
        }
    }

    /**
     * 根据标签名称查找所有相关标签（通过最多2次边连接）
     * 返回包括自身在内的所有相关标签名称
     */
    public List<String> findRelatedTagNames(String tagName) {
        try {
            List<String> relatedTags = tagNodeRepository.findRelatedTagNames(tagName);
            if (!relatedTags.contains(tagName)) {
                relatedTags.add(tagName);
            }
            logger.info("标签 {} 的相关标签: {}", tagName, relatedTags);
            return relatedTags;
        } catch (Exception e) {
            logger.error("查找相关标签失败: {}", tagName, e);
            // 如果出错，至少返回自身
            return Collections.singletonList(tagName);
        }
    }

    /**
     * 根据多个标签名称查找所有相关标签
     */
    public List<String> findRelatedTagNames(List<String> tagNames) {
        try {
            if (tagNames == null || tagNames.isEmpty()) {
                return Collections.emptyList();
            }
            List<String> relatedTags = tagNodeRepository.findRelatedTagNamesByMultiple(tagNames);
            // 确保包含原始标签
            Set<String> result = new HashSet<>(relatedTags);
            result.addAll(tagNames);
            logger.info("标签 {} 的相关标签: {}", tagNames, result);
            return new ArrayList<>(result);
        } catch (Exception e) {
            logger.error("查找相关标签失败: {}", tagNames, e);
            return tagNames;
        }
    }

    /**
     * 初始化标签关系图
     * 构建一个示例的标签层次结构
     */
    public void initializeTagGraph() {
        if (tagNodeRepository == null) {
            logger.warn("TagNodeRepository未注入，跳过标签关系图初始化");
            return;
        }
        
        logger.info("开始初始化标签关系图...");
        
        try {
            // 先清理可能存在的重复标签
            logger.info("检查并清理重复标签...");
            cleanupDuplicateTags();

            // 创建顶级标签
            logger.info("创建顶级标签...");
            createOrUpdateTag("Fiction", "小说类");
            createOrUpdateTag("Non-Fiction", "非小说类");

            // Fiction的子分类
            logger.info("创建Fiction的子分类...");
            createSubcategoryRelation("Science Fiction", "Fiction");
            createSubcategoryRelation("Fantasy", "Fiction");
            createSubcategoryRelation("Mystery", "Fiction");
            createSubcategoryRelation("Romance", "Fiction");
            createSubcategoryRelation("Thriller", "Fiction");
            createSubcategoryRelation("Horror", "Fiction");

            // Non-Fiction的子分类
            logger.info("创建Non-Fiction的子分类...");
            createSubcategoryRelation("Biography", "Non-Fiction");
            createSubcategoryRelation("History", "Non-Fiction");
            createSubcategoryRelation("Science", "Non-Fiction");
            createSubcategoryRelation("Business", "Non-Fiction");
            createSubcategoryRelation("Education", "Non-Fiction");

            // Science的子分类
            logger.info("创建Science的子分类...");
            createSubcategoryRelation("Technology", "Science");
            createSubcategoryRelation("Mathematics", "Science");
            createSubcategoryRelation("Programming", "Technology");

            // 其他独立标签
            logger.info("创建其他独立标签...");
            createOrUpdateTag("Literature", "文学");
            createOrUpdateTag("Poetry", "诗歌");
            createOrUpdateTag("Art", "艺术");
            createOrUpdateTag("Philosophy", "哲学");

            logger.info("标签关系图初始化完成");
        } catch (Exception e) {
            logger.error("初始化标签关系图时发生错误", e);
            throw e;
        }
    }

    /**
     * 清理重复的标签节点
     */
    private void cleanupDuplicateTags() {
        try {
            List<TagNode> allTags = tagNodeRepository.findAll();
            Map<String, TagNode> uniqueTags = new HashMap<>();
            
            for (TagNode tag : allTags) {
                String tagName = tag.getName();
                if (tagName == null) {
                    continue;
                }
                
                if (uniqueTags.containsKey(tagName)) {
                    // 发现重复，删除这个节点
                    logger.warn("发现重复标签，删除: {}", tagName);
                    tagNodeRepository.delete(tag);
                } else {
                    // 保留第一个
                    uniqueTags.put(tagName, tag);
                }
            }
            logger.info("清理完成，保留 {} 个唯一标签", uniqueTags.size());
        } catch (Exception e) {
            logger.warn("清理重复标签时发生错误（可忽略）: {}", e.getMessage());
        }
    }

    /**
     * 清理指定名称的重复标签节点
     */
    private void cleanupDuplicateTagByName(String tagName) {
        try {
            List<TagNode> tags = tagNodeRepository.findAllByName(tagName);
            if (tags.size() > 1) {
                logger.warn("发现 {} 个重复标签 '{}'，删除多余的", tags.size(), tagName);
                // 保留第一个，删除其他的
                for (int i = 1; i < tags.size(); i++) {
                    tagNodeRepository.delete(tags.get(i));
                }
            }
        } catch (Exception e) {
            logger.warn("清理标签 '{}' 的重复项时发生错误: {}", tagName, e.getMessage());
        }
    }

    /**
     * 获取所有标签节点
     */
    public List<TagNode> getAllTags() {
        return tagNodeRepository.findAll();
    }
}

