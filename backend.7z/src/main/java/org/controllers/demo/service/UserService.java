package org.controllers.demo.service;

import org.controllers.demo.entity.UserMeta;
import org.controllers.demo.entity.UserProfile;
import java.util.List;

public interface UserService {
    UserMeta register(String username, String password);
    UserMeta login(String username, String password);
    boolean isUsernameExists(String username);
    UserProfile registerUser(String username, String password, String email, String phone, String description);
    UserProfile getUserProfile(String userId);
    List<UserProfile> getAllUsers();
    UserProfile updateUserStatus(String userId, String status);
} 