package org.controllers.demo.service.remote;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Component
public class OrderPricingClient {

    private static final Logger log = LoggerFactory.getLogger(OrderPricingClient.class);

    private final RestTemplate restTemplate;
    private final String pricingServiceUrl;

    public OrderPricingClient(RestTemplate restTemplate,
                              @Value("${function.service.url}") String pricingServiceUrl) {
        this.restTemplate = restTemplate;
        this.pricingServiceUrl = pricingServiceUrl;
    }

    public BigDecimal calculateLineTotal(BigDecimal unitPrice, int quantity) {
        log.debug("调用函数式服务计算订单小计，unitPrice={}, quantity={}", unitPrice, quantity);
        Map<String, Object> body = new HashMap<>();
        body.put("unitPrice", unitPrice);
        body.put("quantity", quantity);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        try {
            Map<?, ?> response = restTemplate.postForObject(pricingServiceUrl, request, Map.class);
            if (response == null || !response.containsKey("totalPrice")) {
                throw new IllegalStateException("Invalid response from pricing service");
            }
            Object value = response.get("totalPrice");
            if (value instanceof Number number) {
                BigDecimal result = BigDecimal.valueOf(number.doubleValue());
                log.info("函数式服务返回小计成功，结果={}", result);
                return BigDecimal.valueOf(number.doubleValue());
            }
            BigDecimal result = new BigDecimal(value.toString());
            log.info("函数式服务返回小计成功，结果={}", result);
            return result;
        } catch (RestClientException | IllegalArgumentException ex) {
            log.error("调用订单定价服务失败，使用本地兜底逻辑: {}", ex.getMessage());
            if (unitPrice == null) {
                return BigDecimal.ZERO;
            }
            return unitPrice.max(BigDecimal.ZERO).multiply(BigDecimal.valueOf(quantity));
        }
    }
}

