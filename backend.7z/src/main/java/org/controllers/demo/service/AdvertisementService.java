package org.controllers.demo.service;

import org.controllers.demo.entity.Advertisement;
import java.util.List;

public interface AdvertisementService {
    List<Advertisement> findAll();
    Advertisement findById(String id);
    Advertisement save(Advertisement advertisement);
    void deleteById(String id);
} 