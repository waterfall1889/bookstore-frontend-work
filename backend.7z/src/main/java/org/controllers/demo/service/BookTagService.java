package org.controllers.demo.service;

import org.controllers.demo.entity.BookTag;
import org.controllers.demo.entity.BookTagRelation;
import org.controllers.demo.entity.Item;
import org.controllers.demo.repository.BookTagRepository;
import org.controllers.demo.repository.BookTagRelationRepository;
import org.controllers.demo.repository.ItemRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class BookTagService {
    private static final Logger logger = LoggerFactory.getLogger(BookTagService.class);

    @Autowired
    private BookTagRepository bookTagRepository;

    @Autowired
    private BookTagRelationRepository bookTagRelationRepository;

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private Neo4jTagService neo4jTagService;

    /**
     * 为图书添加标签
     */
    @Transactional
    public void addTagToBook(String itemId, String tagName) {
        BookTag tag = bookTagRepository.findByTagName(tagName)
                .orElseGet(() -> {
                    BookTag newTag = new BookTag();
                    newTag.setTagName(tagName);
                    return bookTagRepository.save(newTag);
                });

        // 检查关联是否已存在
        List<BookTagRelation> existing = bookTagRelationRepository.findByItemId(itemId);
        boolean exists = existing.stream()
                .anyMatch(rel -> rel.getTagId().equals(tag.getTagId()));

        if (!exists) {
            BookTagRelation relation = new BookTagRelation();
            relation.setItemId(itemId);
            relation.setTagId(tag.getTagId());
            bookTagRelationRepository.save(relation);
            logger.info("为图书 {} 添加标签 {}", itemId, tagName);
        }
    }

    /**
     * 为图书添加多个标签
     */
    @Transactional
    public void addTagsToBook(String itemId, List<String> tagNames) {
        for (String tagName : tagNames) {
            addTagToBook(itemId, tagName);
        }
    }

    /**
     * 移除图书的标签
     */
    @Transactional
    public void removeTagFromBook(String itemId, String tagName) {
        BookTag tag = bookTagRepository.findByTagName(tagName).orElse(null);
        if (tag != null) {
            bookTagRelationRepository.deleteByItemIdAndTagId(itemId, tag.getTagId());
            logger.info("从图书 {} 移除标签 {}", itemId, tagName);
        }
    }

    /**
     * 获取图书的所有标签
     */
    public List<BookTag> getBookTags(String itemId) {
        List<BookTagRelation> relations = bookTagRelationRepository.findByItemId(itemId);
        return relations.stream()
                .map(rel -> {
                    Optional<BookTag> tag = bookTagRepository.findById(rel.getTagId());
                    return tag.orElse(null);
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    /**
     * 根据标签名称搜索图书（包括相关标签）
     * 使用Neo4J查找相关标签，然后在MySQL中搜索
     */
    public List<Item> searchBooksByTag(String tagName) {
        logger.info("根据标签搜索图书: {}", tagName);

        // 1. 从Neo4J获取相关标签（包括自身和通过2次边连接的所有标签）
        List<String> relatedTagNames = neo4jTagService.findRelatedTagNames(tagName);
        logger.info("找到相关标签: {}", relatedTagNames);

        // 2. 从MySQL获取这些标签的ID
        List<BookTag> tags = bookTagRepository.findByTagNameIn(relatedTagNames);
        if (tags.isEmpty()) {
            logger.warn("未找到标签: {}", relatedTagNames);
            return Collections.emptyList();
        }

        List<Integer> tagIds = tags.stream()
                .map(BookTag::getTagId)
                .collect(Collectors.toList());

        // 3. 查找所有带有这些标签的图书ID
        List<String> itemIds = bookTagRelationRepository.findItemIdsByTagIds(tagIds);
        if (itemIds.isEmpty()) {
            logger.info("未找到带有这些标签的图书");
            return Collections.emptyList();
        }

        // 4. 获取图书详细信息
        List<Item> books = itemRepository.findAllById(itemIds);
        // 只返回有效的图书
        books = books.stream()
                .filter(book -> book.getValidness() != null && book.getValidness() == 1)
                .collect(Collectors.toList());

        logger.info("找到 {} 本相关图书", books.size());
        return books;
    }

    /**
     * 根据多个标签名称搜索图书
     */
    public List<Item> searchBooksByTags(List<String> tagNames) {
        logger.info("根据多个标签搜索图书: {}", tagNames);

        // 1. 从Neo4J获取所有相关标签
        List<String> relatedTagNames = neo4jTagService.findRelatedTagNames(tagNames);
        logger.info("找到相关标签: {}", relatedTagNames);

        // 2. 从MySQL获取这些标签的ID
        List<BookTag> tags = bookTagRepository.findByTagNameIn(relatedTagNames);
        if (tags.isEmpty()) {
            logger.warn("未找到标签: {}", relatedTagNames);
            return Collections.emptyList();
        }

        List<Integer> tagIds = tags.stream()
                .map(BookTag::getTagId)
                .collect(Collectors.toList());

        // 3. 查找所有带有这些标签的图书ID
        List<String> itemIds = bookTagRelationRepository.findItemIdsByTagIds(tagIds);
        if (itemIds.isEmpty()) {
            logger.info("未找到带有这些标签的图书");
            return Collections.emptyList();
        }

        // 4. 获取图书详细信息
        List<Item> books = itemRepository.findAllById(itemIds);
        // 只返回有效的图书
        books = books.stream()
                .filter(book -> book.getValidness() != null && book.getValidness() == 1)
                .collect(Collectors.toList());

        logger.info("找到 {} 本相关图书", books.size());
        return books;
    }

    /**
     * 获取所有标签
     */
    public List<BookTag> getAllTags() {
        return bookTagRepository.findAll();
    }

    /**
     * 创建标签（如果不存在）
     */
    @Transactional
    public BookTag createTag(String tagName, String description) {
        return bookTagRepository.findByTagName(tagName)
                .orElseGet(() -> {
                    BookTag tag = new BookTag();
                    tag.setTagName(tagName);
                    tag.setDescription(description);
                    return bookTagRepository.save(tag);
                });
    }
}

