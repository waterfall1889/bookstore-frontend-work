package org.controllers.demo.service;

import org.controllers.demo.entity.mongodb.AvatarFile;
import org.controllers.demo.repository.mongodb.AvatarFileRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

/**
 * 头像服务
 * 处理头像的上传、获取和删除
 */
@Service
public class AvatarService {
    private static final Logger logger = LoggerFactory.getLogger(AvatarService.class);
    
    // 最大文件大小：5MB
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;
    
    // 允许的文件类型
    private static final String[] ALLOWED_CONTENT_TYPES = {
        "image/jpeg", "image/jpg", "image/png", "image/gif", "image/webp"
    };

    @Autowired
    private AvatarFileRepository avatarFileRepository;

    /**
     * 上传用户头像
     */
    public String uploadAvatar(String userId, MultipartFile file) throws IOException {
        logger.info("开始上传头像 - 用户ID: {}, 文件名: {}", userId, file.getOriginalFilename());
        
        // 验证文件
        validateFile(file);
        
        // 将旧头像标记为非激活
        deactivateOldAvatars(userId);
        
        // 创建新头像记录
        AvatarFile avatarFile = new AvatarFile();
        avatarFile.setUserId(userId);
        avatarFile.setFilename(file.getOriginalFilename());
        avatarFile.setContentType(file.getContentType());
        avatarFile.setFileSize(file.getSize());
        avatarFile.setContent(file.getBytes());
        avatarFile.setUploadTime(LocalDateTime.now());
        avatarFile.setIsActive(true);
        
        AvatarFile saved = avatarFileRepository.save(avatarFile);
        logger.info("头像上传成功 - 用户ID: {}, 头像ID: {}", userId, saved.getId());
        
        // 返回头像访问URL
        return "/api/avatar/" + saved.getId();
    }

    /**
     * 根据头像ID获取头像
     */
    public AvatarFile getAvatarById(String avatarId) {
        Optional<AvatarFile> avatar = avatarFileRepository.findById(avatarId);
        if (avatar.isPresent()) {
            logger.debug("获取头像成功 - 头像ID: {}", avatarId);
            return avatar.get();
        }
        logger.warn("头像不存在 - 头像ID: {}", avatarId);
        return null;
    }

    /**
     * 根据用户ID获取当前激活的头像
     */
    public AvatarFile getActiveAvatarByUserId(String userId) {
        Optional<AvatarFile> avatar = avatarFileRepository.findByUserIdAndIsActiveTrue(userId);
        if (avatar.isPresent()) {
            logger.debug("获取用户激活头像成功 - 用户ID: {}", userId);
            return avatar.get();
        }
        logger.debug("用户没有激活的头像 - 用户ID: {}", userId);
        return null;
    }

    /**
     * 获取头像的Base64编码数据URL（用于前端直接显示）
     */
    public String getAvatarDataUrl(String userId) {
        AvatarFile avatar = getActiveAvatarByUserId(userId);
        if (avatar != null && avatar.getContent() != null) {
            String base64 = Base64.getEncoder().encodeToString(avatar.getContent());
            return "data:" + avatar.getContentType() + ";base64," + base64;
        }
        return null;
    }

    /**
     * 删除用户的所有头像
     */
    public void deleteUserAvatars(String userId) {
        logger.info("删除用户所有头像 - 用户ID: {}", userId);
        avatarFileRepository.deleteByUserId(userId);
    }

    /**
     * 验证上传的文件
     */
    private void validateFile(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("文件不能为空");
        }
        
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("文件大小不能超过5MB");
        }
        
        String contentType = file.getContentType();
        boolean allowed = false;
        for (String allowedType : ALLOWED_CONTENT_TYPES) {
            if (allowedType.equals(contentType)) {
                allowed = true;
                break;
            }
        }
        
        if (!allowed) {
            throw new IllegalArgumentException("不支持的文件类型，仅支持: JPEG, PNG, GIF, WebP");
        }
    }

    /**
     * 将用户的所有旧头像标记为非激活
     */
    private void deactivateOldAvatars(String userId) {
        List<AvatarFile> oldAvatars = avatarFileRepository.findByUserId(userId);
        for (AvatarFile oldAvatar : oldAvatars) {
            if (oldAvatar.getIsActive() != null && oldAvatar.getIsActive()) {
                oldAvatar.setIsActive(false);
                avatarFileRepository.save(oldAvatar);
            }
        }
    }
}

