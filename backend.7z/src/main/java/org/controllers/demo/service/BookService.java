package org.controllers.demo.service;

import org.controllers.demo.entity.Item;
import java.util.List;
 
public interface BookService {
    List<Item> getAllBooks();
    Item getBookById(String bookId);
    Item getBookByName(String name);
} 