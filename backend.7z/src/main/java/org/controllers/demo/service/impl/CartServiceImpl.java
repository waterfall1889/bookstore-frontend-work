package org.controllers.demo.service.impl;

import org.controllers.demo.entity.CartItem;
import org.controllers.demo.entity.Item;
import org.controllers.demo.repository.CartItemRepository;
import org.controllers.demo.repository.ItemRepository;
import org.controllers.demo.service.CartService;
import org.controllers.demo.dao.CartDao;
import org.controllers.demo.dao.ItemDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {
    private static final Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

    @Autowired
    private CartDao cartDao;

    @Autowired
    private ItemDao itemDao;

    @Override
    public List<CartItem> getCartItems(String userId) {
        return cartDao.findByUserId(userId);
    }

    @Override
    @Transactional
    public CartItem addToCart(String userId, String itemId, Integer quantity) {
        logger.info("开始添加商品到购物车 - userId: {}, itemId: {}, quantity: {}", userId, itemId, quantity);
        
        // 检查商品是否存在（会从缓存读取）
        Item item = itemDao.findById(itemId);
        if (item == null) {
            logger.warn("商品不存在 - itemId: {}", itemId);
            throw new RuntimeException("商品不存在");
        }

        // 检查库存（库存会从缓存读取）
        logger.info("检查库存 - itemId: {}, 当前库存: {}, 需要: {}", itemId, item.getRemainNumber(), quantity);
        if (item.getRemainNumber() < quantity) {
            logger.warn("商品库存不足 - itemId: {}, 当前库存: {}, 需要: {}", itemId, item.getRemainNumber(), quantity);
            throw new RuntimeException("商品库存不足");
        }

        CartItem existingItem = cartDao.findByUserIdAndItemId(userId, itemId);
        if (existingItem != null) {
            // 如果商品已存在，增加指定数量
            existingItem.setCounts(existingItem.getCounts() + quantity);
            logger.info("更新购物车中商品数量 - userId: {}, itemId: {}, 新数量: {}", 
                userId, itemId, existingItem.getCounts());
            return cartDao.save(existingItem);
        }

        // 如果是新商品，创建新的购物车项
        CartItem cartItem = new CartItem();
        cartItem.setUserId(userId);
        cartItem.setItemId(itemId);
        cartItem.setCounts(quantity);
        logger.info("创建新的购物车项 - userId: {}, itemId: {}, quantity: {}", userId, itemId, quantity);
        return cartDao.save(cartItem);
    }

    @Override
    @Transactional
    public CartItem updateCartItemCount(String userId, String itemId, Integer counts) {
        logger.info("开始更新购物车商品数量 - userId: {}, itemId: {}, counts: {}", userId, itemId, counts);
        
        // 检查商品是否存在（会从缓存读取）
        Item item = itemDao.findById(itemId);
        if (item == null) {
            logger.warn("商品不存在 - itemId: {}", itemId);
            throw new RuntimeException("商品不存在");
        }

        // 检查库存（库存会从缓存读取）
        logger.info("检查库存 - itemId: {}, 当前库存: {}, 需要: {}", itemId, item.getRemainNumber(), counts);
        if (item.getRemainNumber() < counts) {
            logger.warn("商品库存不足 - itemId: {}, 当前库存: {}, 需要: {}", itemId, item.getRemainNumber(), counts);
            throw new RuntimeException("商品库存不足");
        }

        CartItem cartItem = cartDao.findByUserIdAndItemId(userId, itemId);
        if (cartItem == null) {
            throw new RuntimeException("购物车中不存在该商品");
        }

        cartItem.setCounts(counts);
        return cartDao.save(cartItem);
    }

    @Override
    @Transactional
    public void removeFromCart(String userId, String itemId) {
        cartDao.deleteByUserIdAndItemId(userId, itemId);
    }

    @Override
    @Transactional
    public void clearCart(String userId) {
        cartDao.deleteByUserId(userId);
    }
} 