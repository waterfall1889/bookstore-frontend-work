package org.controllers.demo.service.impl;

import org.controllers.demo.service.SessionTimerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
@Scope("singleton")
public class SessionTimerServiceImpl implements SessionTimerService {
    private static final Logger logger = LoggerFactory.getLogger(SessionTimerServiceImpl.class);

    // 存储用户会话开始时间
    private final ConcurrentHashMap<String, Long> sessionStartTimes = new ConcurrentHashMap<>();

    // 定时清理任务
    private final ScheduledExecutorService cleanupExecutor = Executors.newSingleThreadScheduledExecutor();

    public SessionTimerServiceImpl() {
        // 每30分钟清理一次过期的计时器（超过24小时的会话）
        cleanupExecutor.scheduleAtFixedRate(this::cleanupExpiredTimers, 30, 30, TimeUnit.MINUTES);
    }

    @Override
    public void startTimer(String userId) {
        long currentTime = System.currentTimeMillis();
        sessionStartTimes.put(userId, currentTime);
        logger.info("开始计时 - 用户ID: {}, 开始时间: {}", userId, currentTime);
    }

    @Override
    public long stopTimer(String userId) {
        Long startTime = sessionStartTimes.remove(userId);
        if (startTime == null) {
            logger.warn("停止计时失败 - 用户ID: {} 的计时器不存在", userId);
            return 0;
        }

        long currentTime = System.currentTimeMillis();
        long sessionDuration = currentTime - startTime;
        logger.info("停止计时 - 用户ID: {}, 会话时长: {} 毫秒 ({} 分钟)",
                userId, sessionDuration, sessionDuration / 60000.0);
        return sessionDuration;
    }

    @Override
    public long getCurrentSessionTime(String userId) {
        Long startTime = sessionStartTimes.get(userId);
        if (startTime == null) {
            return 0;
        }

        long currentTime = System.currentTimeMillis();
        long sessionDuration = currentTime - startTime;
        logger.debug("获取当前会话时长 - 用户ID: {}, 当前时长: {} 毫秒", userId, sessionDuration);
        return sessionDuration;
    }

    @Override
    public void cleanupExpiredTimers() {
        long currentTime = System.currentTimeMillis();
        long maxSessionTime = 24 * 60 * 60 * 1000; // 24小时

        sessionStartTimes.entrySet().removeIf(entry -> {
            long sessionDuration = currentTime - entry.getValue();
            if (sessionDuration > maxSessionTime) {
                logger.info("清理过期计时器 - 用户ID: {}, 会话时长: {} 毫秒", entry.getKey(), sessionDuration);
                return true;
            }
            return false;
        });
    }
}