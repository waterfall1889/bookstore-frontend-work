package org.controllers.demo.service.impl;

import org.controllers.demo.cache.BookCacheService;
import org.controllers.demo.dao.ItemDao;
import org.controllers.demo.entity.Item;
import org.controllers.demo.repository.ItemRepository;
import org.controllers.demo.service.BookService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    private static final Logger logger = LoggerFactory.getLogger(BookServiceImpl.class);

    @Autowired
    private ItemRepository itemRepository;
    
    @Autowired
    private ItemDao itemDao;

    @Override
    public List<Item> getAllBooks() {
        logger.info("开始获取所有有效图书列表");
        // 查询有效图书列表时，直接从数据库读取
        // 注意：如果需要缓存列表，可以在BookCacheService中添加列表缓存逻辑
        List<Item> books = itemRepository.findAllByValidness(1);
        logger.info("获取所有有效图书列表完成，数量: {}", books != null ? books.size() : 0);
        return books;
    }

    @Override
    public Item getBookById(String bookId) {
        logger.info("开始通过ID获取图书 - bookId: {}", bookId);
        // 使用ItemDao，它会自动处理缓存
        Item book = itemDao.findById(bookId);
        logger.info("通过ID获取图书完成 - bookId: {}, found: {}", bookId, book != null);
        return book;
    }

    @Override
    public Item getBookByName(String name) {
        logger.info("开始通过名称获取图书 - name: {}", name);
        if (name == null || name.trim().isEmpty()) {
            logger.warn("图书名称为空");
            return null;
        }
        // 按名称查询时，直接从数据库查询（因为名称可能不是唯一标识）
        Item book = itemRepository.findByItemNameAndValidness(name.trim(), 1);
        logger.info("通过名称获取图书完成 - name: {}, found: {}", name, book != null);
        return book;
    }

} 