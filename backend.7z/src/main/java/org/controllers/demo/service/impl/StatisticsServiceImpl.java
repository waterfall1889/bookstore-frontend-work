package org.controllers.demo.service.impl;

import org.controllers.demo.entity.Item;
import org.controllers.demo.entity.OrderItem;
import org.controllers.demo.entity.OrderMeta;
import org.controllers.demo.repository.OrderItemRepository;
import org.controllers.demo.repository.OrderMetaRepository;
import org.controllers.demo.service.StatisticsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StatisticsServiceImpl implements StatisticsService {
    private static final Logger logger = LoggerFactory.getLogger(StatisticsServiceImpl.class);

    @Autowired
    private OrderMetaRepository orderMetaRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    @Override
    public Map<String, Object> getUserStatistics(String userId, String startDate, String endDate) {
        logger.info("开始统计用户[{}]在{}至{}期间的购书数据", userId, startDate, endDate);
        
        // 获取指定时间范围内的有效订单
        List<OrderMeta> orders = orderMetaRepository.findByUserIdAndDateBetween(userId, startDate, endDate);
        logger.info("查询到{}个订单", orders.size());
        
        if (orders.isEmpty()) {
            // 添加调试信息，查询所有订单以验证日期格式
            List<OrderMeta> allOrders = orderMetaRepository.findByUserId(userId);
            logger.info("用户[{}]的所有订单数量: {}", userId, allOrders.size());
            if (!allOrders.isEmpty()) {
                logger.info("订单日期示例: {}", allOrders.get(0).getDate());
                // 打印所有订单的日期和状态
                for (OrderMeta order : allOrders) {
                    logger.info("订单[{}] - 日期: {}, 状态: {}", 
                        order.getOrderId(), order.getDate(), order.getStatus());
                }
            }
        }
        
        // 获取所有订单项
        List<OrderItem> allOrderItems = new ArrayList<>();
        for (OrderMeta order : orders) {
            List<OrderItem> items = orderItemRepository.findByOrderId(order.getOrderId());
            logger.info("订单[{}]包含{}个商品项", order.getOrderId(), items.size());
            if (!items.isEmpty()) {
                for (OrderItem item : items) {
                    logger.info("订单项: 商品ID={}, 数量={}", item.getItemId(), item.getCounts());
                }
            }
            allOrderItems.addAll(items);
        }
        logger.info("总共获取到{}个订单项", allOrderItems.size());

        // 按书籍分组统计
        Map<Item, List<OrderItem>> bookGroups = allOrderItems.stream()
            .collect(Collectors.groupingBy(OrderItem::getItem));
        logger.info("按书籍分组后共有{}种不同的书籍", bookGroups.size());

        // 计算每本书的统计数据
        List<Map<String, Object>> bookStatistics = new ArrayList<>();
        int totalQuantity = 0;
        BigDecimal totalAmount = BigDecimal.ZERO;

        for (Map.Entry<Item, List<OrderItem>> entry : bookGroups.entrySet()) {
            Item book = entry.getKey();
            List<OrderItem> items = entry.getValue();

            int quantity = items.stream()
                .mapToInt(OrderItem::getCounts)
                .sum();

            BigDecimal amount = items.stream()
                .map(item -> book.getPrice().multiply(new BigDecimal(item.getCounts())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

            logger.info("书籍[{}]统计: 数量={}, 金额={}", 
                book.getItemName(), quantity, amount);

            Map<String, Object> bookStat = new HashMap<>();
            bookStat.put("bookName", book.getItemName());
            bookStat.put("quantity", quantity);
            bookStat.put("totalAmount", amount.doubleValue());

            bookStatistics.add(bookStat);
            totalQuantity += quantity;
            totalAmount = totalAmount.add(amount);
        }

        // 按购买数量排序
        bookStatistics.sort((a, b) -> 
            ((Integer) b.get("quantity")).compareTo((Integer) a.get("quantity")));
        logger.info("排序后的书籍统计结果: {}", bookStatistics);


        // 构建最终结果
        Map<String, Object> result = new HashMap<>();
        result.put("totalQuantity", totalQuantity);
        result.put("totalAmount", totalAmount.doubleValue());
        result.put("bookStatistics", bookStatistics);

        logger.info("统计完成: 总数量={}, 总金额={}", totalQuantity, totalAmount);
        return result;
    }

    @Override
    public Map<String, Object> getAllStatistics(String startDate, String endDate) {
        logger.info("开始统计在{}至{}期间的购书数据", startDate, endDate);

        // 获取指定时间范围内的有效订单
        List<OrderMeta> orders = orderMetaRepository.findByDateBetween(startDate, endDate);
        logger.info("查询到{}个订单", orders.size());

        // 获取所有订单项并预加载商品信息
        List<OrderItem> allOrderItems = new ArrayList<>();
        for (OrderMeta order : orders) {
            // 使用JOIN FETCH加载关联的商品信息
            List<OrderItem> items = orderItemRepository.findByOrderIdWithItem(order.getOrderId());
            logger.info("订单[{}]包含{}个商品项", order.getOrderId(), items.size());
            allOrderItems.addAll(items);
        }
        logger.info("总共获取到{}个订单项", allOrderItems.size());

        // 初始化统计结果
        int totalQuantity = 0;
        BigDecimal totalAmount = BigDecimal.ZERO;

        // 书籍统计
        Map<Item, List<OrderItem>> bookGroups = allOrderItems.stream()
                .filter(orderItem -> orderItem.getItem() != null) // 过滤掉无效项
                .collect(Collectors.groupingBy(OrderItem::getItem));

        logger.info("按书籍分组后共有{}种不同的书籍", bookGroups.size());
        List<Map<String, Object>> bookStatistics = new ArrayList<>();

        // 用户统计
        Map<String, List<OrderItem>> userGroups = allOrderItems.stream()
                .filter(orderItem -> orderItem.getOrderMeta() != null) // 过滤掉无效项
                .collect(Collectors.groupingBy(orderItem ->
                        orderItem.getOrderMeta().getUserId()));

        logger.info("按用户分组后共有{}个用户", userGroups.size());
        List<Map<String, Object>> userStatistics = new ArrayList<>();

        // 一次性处理所有书籍统计
        for (Map.Entry<Item, List<OrderItem>> entry : bookGroups.entrySet()) {
            Item book = entry.getKey();
            List<OrderItem> items = entry.getValue();

            int quantity = items.stream()
                    .mapToInt(OrderItem::getCounts)
                    .sum();

            BigDecimal amount = items.stream()
                    .map(item -> book.getPrice().multiply(BigDecimal.valueOf(item.getCounts())))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            logger.info("书籍[{}]统计: 数量={}, 金额={}",
                    book.getItemName(), quantity, amount);

            Map<String, Object> bookStat = new HashMap<>();
            bookStat.put("bookName", book.getItemName());
            bookStat.put("quantity", quantity);
            bookStat.put("totalAmount", amount.doubleValue());

            bookStatistics.add(bookStat);
            totalQuantity += quantity;
            totalAmount = totalAmount.add(amount);
        }

        // 按购买数量排序
        bookStatistics.sort((a, b) ->
                ((Integer) b.get("quantity")).compareTo((Integer) a.get("quantity")));
        logger.info("排序后的书籍统计结果: {}", bookStatistics);

        // 一次性处理所有用户统计
        for (Map.Entry<String, List<OrderItem>> entry : userGroups.entrySet()) {
            String userId = entry.getKey();
            List<OrderItem> userItems = entry.getValue();

            // 计算用户总消费金额 (使用BigDecimal保持精度)
            BigDecimal userTotalAmount = userItems.stream()
                    .filter(item -> item.getItem() != null && item.getItem().getPrice() != null)
                    .map(item -> item.getItem().getPrice().multiply(BigDecimal.valueOf(item.getCounts())))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            // 计算购买的商品总数
            int userTotalItems = userItems.stream()
                    .mapToInt(OrderItem::getCounts)
                    .sum();

            // 计算购买的不同商品种类数
            long distinctItems = userItems.stream()
                    .map(OrderItem::getItemId)
                    .distinct()
                    .count();

            // 构建用户统计信息
            Map<String, Object> userStat = new HashMap<>();
            userStat.put("userId", userId);
            userStat.put("totalAmount", userTotalAmount.doubleValue()); // 转换为double用于JSON
            userStat.put("totalItems", userTotalItems);
            userStat.put("distinctItems", distinctItems);

            // 添加详细购买记录（可选）
            List<Map<String, Object>> purchaseDetails = userItems.stream()
                    .map(item -> {
                        Map<String, Object> detail = new HashMap<>();
                        detail.put("itemId", item.getItemId());
                        detail.put("itemName", item.getItem() != null ?
                                item.getItem().getItemName() : "未知商品");
                        detail.put("quantity", item.getCounts());
                        detail.put("price", item.getItem() != null ?
                                item.getItem().getPrice().doubleValue() : 0.0);
                        detail.put("subtotal", (item.getItem() != null ?
                                item.getItem().getPrice().multiply(BigDecimal.valueOf(item.getCounts())) :
                                BigDecimal.ZERO).doubleValue());
                        return detail;
                    })
                    .collect(Collectors.toList());

            userStat.put("purchaseDetails", purchaseDetails);
            userStatistics.add(userStat);
        }

        // 按总消费金额降序排序
        userStatistics.sort((a, b) ->
                Double.compare((Double) b.get("totalAmount"), (Double) a.get("totalAmount")));
        logger.info("生成用户统计信息: {}条记录", userStatistics.size());

        // 构建最终结果
        Map<String, Object> result = new HashMap<>();
        result.put("totalQuantity", totalQuantity);
        result.put("totalAmount", totalAmount.doubleValue()); // 转换为double用于JSON
        result.put("bookStatistics", bookStatistics);
        result.put("userStatistics", userStatistics);

        logger.info("统计完成: 总数量={}, 总金额={}", totalQuantity, totalAmount);
        return result;
    }
} 