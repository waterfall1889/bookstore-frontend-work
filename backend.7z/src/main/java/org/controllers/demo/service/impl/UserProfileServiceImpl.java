package org.controllers.demo.service.impl;

import org.controllers.demo.entity.UserProfile;
import org.controllers.demo.dao.UserProfileDao;
import org.controllers.demo.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

@Service
public class UserProfileServiceImpl implements UserProfileService {

    @Autowired
    private UserProfileDao userProfileDao;

    @Override
    public UserProfile getUserProfile(String userId) {
        return userProfileDao.findByIdWithUserMeta(userId);
    }

    @Override
    @Transactional
    public UserProfile updateUserProfile(String userId, Map<String, String> updates) {
        UserProfile profile = userProfileDao.findByIdWithUserMeta(userId);
        if (profile == null) {
            throw new RuntimeException("用户不存在");
        }

        // 更新基本信息
        if (updates.containsKey("email")) {
            profile.setEmail(updates.get("email"));
        }
        if (updates.containsKey("phone")) {
            profile.setPhone(updates.get("phone"));
        }
        if (updates.containsKey("description")) {
            profile.setDescription(updates.get("description"));
        }

        return userProfileDao.save(profile);
    }

    @Override
    @Transactional
    public boolean updateAvatar(String userId, String avatarUrl) {
        UserProfile profile = userProfileDao.findByIdWithUserMeta(userId);
        if (profile == null) {
            throw new RuntimeException("用户不存在");
        }

        profile.setAvatarUrl(avatarUrl);
        userProfileDao.save(profile);
        return true;
    }
} 