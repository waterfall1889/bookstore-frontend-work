package org.controllers.demo.service.impl;

import org.controllers.demo.entity.Advertisement;
import org.controllers.demo.repository.AdvertisementRepository;
import org.controllers.demo.service.AdvertisementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdvertisementServiceImpl implements AdvertisementService {

    @Autowired
    private AdvertisementRepository repository;

    @Override
    public List<Advertisement> findAll() {
        return repository.findAll();
    }

    @Override
    public Advertisement findById(String id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public Advertisement save(Advertisement advertisement) {
        return repository.save(advertisement);
    }

    @Override
    public void deleteById(String id) {
        repository.deleteById(id);
    }
} 