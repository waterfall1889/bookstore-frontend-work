package org.controllers.demo.service;

import org.controllers.demo.entity.CartItem;
import java.util.List;

public interface CartService {
    List<CartItem> getCartItems(String userId);
    CartItem addToCart(String userId, String itemId, Integer quantity);
    CartItem updateCartItemCount(String userId, String itemId, Integer counts);
    void removeFromCart(String userId, String itemId);
    void clearCart(String userId);
} 