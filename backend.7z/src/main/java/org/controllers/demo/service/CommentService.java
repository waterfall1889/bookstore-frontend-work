package org.controllers.demo.service;

import org.controllers.demo.entity.Comment;
import java.util.List;

public interface CommentService {
    Comment createComment(Comment comment);
    Comment updateComment(String commentId, Comment comment);
    void deleteComment(String commentId);
    Comment getCommentById(String commentId);
    List<Comment> getCommentsByItemId(String itemId);
    List<Comment> getCommentsByCommenterId(String commenterId);
    Double getAverageRatingByItemId(String itemId);
    List<Comment> getCommentsByItemIdOrderByTimeDesc(String itemId);
} 