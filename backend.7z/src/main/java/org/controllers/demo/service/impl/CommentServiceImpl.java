package org.controllers.demo.service.impl;

import org.controllers.demo.entity.Comment;
import org.controllers.demo.repository.CommentRepository;
import org.controllers.demo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Override
    @Transactional
    public Comment createComment(Comment comment) {
        comment.setCommentId(generateCommentId());
        comment.setCommentTime(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        return commentRepository.save(comment);
    }

    @Override
    @Transactional
    public Comment updateComment(String commentId, Comment comment) {
        Comment existingComment = commentRepository.findById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
        
        existingComment.setRating(comment.getRating());
        existingComment.setComment(comment.getComment());
        
        return commentRepository.save(existingComment);
    }

    @Override
    @Transactional
    public void deleteComment(String commentId) {
        commentRepository.deleteById(commentId);
    }

    @Override
    public Comment getCommentById(String commentId) {
        return commentRepository.findById(commentId)
                .orElseThrow(() -> new RuntimeException("评论不存在"));
    }

    @Override
    public List<Comment> getCommentsByItemId(String itemId) {
        return commentRepository.findByItemIdWithUserInfo(itemId);
    }

    @Override
    public List<Comment> getCommentsByCommenterId(String commenterId) {
        return commentRepository.findByCommenterIdWithUserInfo(commenterId);
    }

    @Override
    public Double getAverageRatingByItemId(String itemId) {
        return commentRepository.getAverageRatingByItemId(itemId);
    }

    @Override
    public List<Comment> getCommentsByItemIdOrderByTimeDesc(String itemId) {
        return commentRepository.findByItemIdOrderByCommentTimeDesc(itemId);
    }

    private String generateCommentId() {
        return UUID.randomUUID().toString().substring(0, 10);
    }
} 