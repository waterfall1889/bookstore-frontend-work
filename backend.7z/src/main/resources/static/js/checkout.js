// 结算函数
export async function checkout(userId, shippingAddress) {
    try {
        const response = await fetch(`http://localhost:8080/api/carts/user/${userId}/checkout?shippingAddress=${encodeURIComponent(shippingAddress)}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || '结算失败');
        }

        return await response.json();
    } catch (error) {
        console.error('结算失败:', error);
        throw error;
    }
}

// 获取购物车信息
export async function getCart(userId) {
    try {
        const response = await fetch(`http://localhost:8080/api/carts/user/${userId}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error('获取购物车信息失败');
        }

        return await response.json();
    } catch (error) {
        console.error('获取购物车信息失败:', error);
        throw error;
    }
}

// 更新购物车商品数量
export async function updateCartItemQuantity(userId, itemId, quantity) {
    try {
        const response = await fetch(`http://localhost:8080/api/carts/user/${userId}/items/${itemId}?quantity=${quantity}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error('更新购物车失败');
        }

        return await response.json();
    } catch (error) {
        console.error('更新购物车失败:', error);
        throw error;
    }
}

// 从购物车中移除商品
export async function removeFromCart(userId, itemId) {
    try {
        const response = await fetch(`http://localhost:8080/api/carts/user/${userId}/items/${itemId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error('移除商品失败');
        }

        return await response.json();
    } catch (error) {
        console.error('移除商品失败:', error);
        throw error;
    }
}

// 清空购物车
export async function clearCart(userId) {
    try {
        const response = await fetch(`http://localhost:8080/api/carts/user/${userId}/clear`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        });

        if (!response.ok) {
            throw new Error('清空购物车失败');
        }
    } catch (error) {
        console.error('清空购物车失败:', error);
        throw error;
    }
} 