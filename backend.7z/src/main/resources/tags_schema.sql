-- 标签表
CREATE TABLE IF NOT EXISTS book_tags (
    tag_id INT AUTO_INCREMENT PRIMARY KEY,
    tag_name VARCHAR(50) NOT NULL UNIQUE COMMENT '标签名称',
    description VARCHAR(200) COMMENT '标签描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_tag_name (tag_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书标签表';

-- 图书-标签关联表
CREATE TABLE IF NOT EXISTS book_tag_relations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_id VARCHAR(9) NOT NULL COMMENT '图书ID',
    tag_id INT NOT NULL COMMENT '标签ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (tag_id) REFERENCES book_tags(tag_id) ON DELETE CASCADE,
    FOREIGN KEY (item_id) REFERENCES item_meta(item_id) ON DELETE CASCADE,
    UNIQUE KEY uk_item_tag (item_id, tag_id),
    INDEX idx_item_id (item_id),
    INDEX idx_tag_id (tag_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书-标签关联表';

-- 插入一些示例标签
INSERT INTO book_tags (tag_name, description) VALUES
('Fiction', '小说类'),
('Non-Fiction', '非小说类'),
('Science Fiction', '科幻小说'),
('Fantasy', '奇幻小说'),
('Mystery', '悬疑小说'),
('Romance', '言情小说'),
('Thriller', '惊悚小说'),
('Horror', '恐怖小说'),
('Biography', '传记'),
('History', '历史'),
('Science', '科学'),
('Technology', '技术'),
('Programming', '编程'),
('Mathematics', '数学'),
('Philosophy', '哲学'),
('Literature', '文学'),
('Poetry', '诗歌'),
('Art', '艺术'),
('Business', '商业'),
('Education', '教育')
ON DUPLICATE KEY UPDATE tag_name=tag_name;

