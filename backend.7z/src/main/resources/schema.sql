-- 修改users_auth表的password字段长度
ALTER TABLE users_auth MODIFY COLUMN password VARCHAR(100); 